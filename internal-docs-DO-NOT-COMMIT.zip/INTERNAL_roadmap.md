# INTERNAL — Roadmap
(Never commit this file or this folder to GitHub.)

The public `roadmap.html` says only: current focus is functionality and
outreach, longer-term direction is still being discussed. This doc is
the actual, honest version.

## Right now: functionality

- ~~Finish wiring the real GoFundMe campaign link~~ — **done (v71)**.
  Campaign is live at
  https://www.gofundme.com/f/amplify-campaigns-waiting-for-a-first-yes
  and wired into `credits.html`'s "Support the app →" button. Funding
  goal: lean, $1,370/3 months.
- Minor cleanup: the live Google Form still asks for email twice.
  **Still open on the actual form** (the picker's code is ready either
  way): switch Settings → Responses → "Collect email addresses" to
  "Responder input," then delete the now-redundant custom "Your email"
  question. Also add a privacy note to the form's top-level description
  covering both "Your name" and email ("for our reference only, never
  published"). Separately, a "Your name" question and the "How can we
  help?" rename (from "What's this about?") are both already live on
  the form — the picker's parser recognizes both label versions.
- Build the actual report form: **done (v58)** — no second Google Form
  needed after all. Added one "What's this about?" question to the
  existing intake form; the picker now routes a single pasted response
  to either the add-campaign flow or the report flow based on that one
  answer, matching the campaign by name instead of a separate ID field.
  See the backend doc's Report Handling section for the plain-language
  version, and the "repo placement" section just above it for why the
  picker itself moved to the private repo.
- Set up the private notifier repo for real: **code complete and
  reviewed (v59)** — `notify-subscribers.js` correctly fetches the
  public campaigns.json, recomputes the daily hero, dedupes sends, and
  fails safely without secrets. What's still actually outstanding:
  (1) create the real private GitHub repo and push these files if that
  hasn't happened yet, (2) add the five SMTP secrets in that repo's
  Settings, (3) build the subscriber-signup-form → `subscribers.json`
  bridge (`credits.html`'s "Get notified" button is still `href="#"`).
  **Also moved into this repo (v59)**: `moderator-picker.html` and
  `blog-composer.html`, previously (incorrectly) bundled with the
  public site files — see the backend doc for why.
- Get a first real accessibility audit and legal review of the privacy
  policy — **still open, no change**. Both are budgeted for in the
  GoFundMe funding worksheet (`INTERNAL_gofundme-campaign-plan.md`) as
  one-time line items ($350 and $250 respectively), so this is blocked
  on the app's own campaign actually launching and raising that money,
  not on any further planning work.

## Right now: outreach

- Start actually sourcing and reviewing real campaigns, not just sample
  data. **Status: complete for the sample-replacement goal** — 10 of 10
  entries are now real campaigns as of this session, zero placeholder
  data left. **New priority**: the dataset currently has zero true
  zero-donation (seed-tier) campaigns — the exact case this project
  exists for — since the last remaining sample entry (Diego) was
  replaced with a real campaign that already has donors. Finding one
  genuine zero-donation campaign is now the highest-priority sourcing
  need, above adding more mid-tier campaigns.
- Image extraction from a saved `.mhtml` page is confirmed working and
  ready to use for any future real campaign, same process as used for
  the two already added — no need to re-verify feasibility each time.
- Begin sending the (revised, non-scam-shaped) good-faith notification
  to featured campaign owners.
- Populate Success Stories as real ones come in — currently empty by
  design, not a placeholder problem to fix.
- Launch the GoFundMe campaign for the app itself once the funding
  worksheet numbers are finalized.

## How GoFundMe's related products actually differ (v51 — verified before writing)

Relevant to understand, not directly relevant to build anything on top
of right now.

**Regular GoFundMe (what every campaign on this board uses)**: free to
start and run. Donors can choose a one-time donation *or* a recurring
monthly donation at checkout (a real, native, built-in option, not a
paid tier) — 5% extra fee charged to the donor for recurring, nothing
extra for the organizer. Not available in every region yet (some
Italy/Canada campaigns lack it per GFM's own docs).

**GoFundMe Pro (formerly "Classy")**: a completely separate, unrelated
product — enterprise nonprofit fundraising software, starting around
$299/month, aimed at registered nonprofits doing donor management,
peer-to-peer campaigns, and large-scale recurring-giving programs.
**This is not a paid upgrade tier of a personal GoFundMe account** —
it's a different business entirely that GFM acquired and rebranded.
Not relevant to Boost Board or any individual featured campaign unless
Boost Board itself someday became a registered nonprofit needing that
kind of tooling — see the "if this grows past a side project" note
elsewhere in this doc.

**Practical takeaway for now**: nothing to build differently. Featured
campaigns may already support recurring donations natively (worth
mentioning to a campaign owner during outreach as a detail they may not
know), and "GoFundMe Pro" should never be confused with or suggested as
something relevant to an individual's personal campaign.

## Open questions — genuinely undecided, not just unannounced

- Whether this stays a personal side project or grows into something
  more formal (NPO, product, etc.) — this is the reason the public repo
  has no LICENSE file and the internal docs stay unpublished: keeping
  that option open on purpose.
- **If this grows past a side project**, `credits.html` (or a successor
  page) is where financial transparency would live — what's been
  raised, what it's gone toward, and what's next. Moved here from the
  public credits page itself, since committing to that level of public
  reporting isn't appropriate to promise before it's actually true.
- Whether/how to expand beyond the current single site into the
  multi-site "one dataset, many front doors" idea floated early on
  (autistic-specific, LGBTQIA-specific instances sharing the same
  backend).
- Whether "First Encourager" or another name ever gets finalized and
  used in copy.
- Whether the fallback eligibility criteria (low percent-of-goal, low
  engagement) need tuning once there's real usage data instead of a
  hand-picked demonstration campaign.

## Content backlog — CTA lines for "over time" use (v56)

Rephrased (not copied) from GFM's own "Become an early supporter / Your
donation matters" pattern, for sprinkling into pages gradually rather
than building a rotating-CTA system right now:
- "Be the reason this doesn't stay quiet."
- "Someone's first yes could be you."
- "A little goes further before anyone else has given."
- "You could be the first name on this page."

## Explicitly not planned right now (not the same as "never")

- Real multi-moderator tooling (concurrent editing, per-user permissions,
  audit trail of who did what) — beyond the current model, which is: you,
  plus select helpers when they're available, all sharing the same
  single `moderator-picker.html` tool and manually coordinating who's
  editing `campaigns.json` at a given moment. That informal model is
  fine at this scale; it just doesn't have any conflict-prevention if
  two people download/edit/upload around the same time — see the
  operations doc's note on this ("no locking" at solo/small-team scale).
- Any paid/reward tier structure (ruled out entirely for GFM; still
  true regardless of platform).
- A native mobile app or anything beyond the current static-site
  approach.

Update this doc as priorities actually shift — it's meant to reflect
reality, not aspiration.
