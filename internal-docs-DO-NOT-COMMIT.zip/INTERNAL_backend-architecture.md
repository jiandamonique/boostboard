# INTERNAL — Backend / Data Architecture
(Never commit this file or this folder to GitHub.)

## Data model

Single source of truth: `campaigns.json`. Fields:

| Field | Type | Meaning |
|---|---|---|
| `id` | string | Stable identifier, never reused |
| `name` | string | Display name |
| `communities` | string[] | Tags — supports multi-identity, cross-listing across future community-specific front doors |
| `description` | string | Short blurb, moderator-written or lightly edited from submission |
| `link` | string | The fundraiser or payment URL. Deliberately platform-agnostic — GoFundMe, Indiegogo, a bare Venmo/CashApp/PayPal.me link, whatever the submitter actually uses. No validation on format beyond it being a URL. |
| `donationCount` | number | Self-reported by submitter, drives tier |
| `submittedDate` | ISO date | Used as tiebreaker in rotation queue order |
| `lastFeatured` | ISO date or null | Last day this appeared on the board |
| `pinned` | bool | Editorial cherry-pick — guaranteed board slot |
| `pinReason` | string | Optional, shown publicly under "Editor's Pick" when set. Only meaningful when `pinned` is true, but harmless if populated otherwise. |
| `reported` | bool | Auto-hides from board regardless of pin status |
| `amountRaised` | number or null | Optional, self-reported dollar total. Only used to compute `percentOfGoal()` for the fallback pathway — has no other effect. |
| `goalAmount` | number or null | Optional, self-reported. Paired with `amountRaised` for the fallback pathway. |
| `lowEngagementFlag` | bool | Optional, manual judgment call only — never computed from any data source. See "Fallback eligibility" below. |

No database, no server. This is intentional for the prototype stage —
static hosting, zero infrastructure cost, one file a moderator can read
and hand-edit if needed. The tradeoff: no concurrent-write safety (two
moderators editing at once can clobber each other), no audit log of who
changed what. Both worth solving for real if/when this becomes a funded
product — likely via a lightweight database (even SQLite via a small API)
plus per-moderator auth instead of a shared JSON file.

## Tier logic

Derived from `donationCount`, not stored directly, so it's always
consistent with the underlying number:

- `seed`: 0
- `first_five`: 1–4
- `first_ten`: 5–9
- `graduated` (implicit, not a real tier): 10+ — excluded from the board
  entirely, treated as a success state, UNLESS it qualifies under the
  fallback criteria below.

## Fallback eligibility (when the normal tiers run thin)

Added per explicit request: donor count alone doesn't capture every
case of a campaign that still needs help. Two new optional fields on a
campaign:
- `amountRaised` / `goalAmount` (numbers, both optional, self-reported)
  — if both are present, `percentOfGoal(c)` computes the percentage.
  Below `LOW_PERCENTAGE_THRESHOLD` (currently 10%, a constant in
  `board-data.js`), the campaign qualifies for the fallback even if
  `donationCount` is 10+.
- `lowEngagementFlag` (bool, optional, default false) — a pure manual
  judgment call, never computed. No platform exposes reach/shares/views
  data via any public API, so this is set by whoever's adding the
  campaign (submission or manual sourcing) when donor count and dollar
  progress both look fine but something else (barely any shares, a
  clearly under-the-radar page) suggests it still needs a boost.

`qualifiesAsFallback(c)` returns true if either condition is met. In
`computeToday()`, the `eligible` pool now includes graduated campaigns
that qualify as fallback — they land in the TLC section (never the Zero
Donations section, since they're not literally at zero donors) with a
transparent label (`fallbackLabel()`) instead of the normal tier badge:
either "`X`% of goal reached" or "Low engagement — added manually."
**Never silently include these without a label** — an unexplained badge
next to a 10+-donor campaign would look like a bug, not a considered
choice.

`archive.html`'s "Success Stories" filter was updated to exclude
fallback-qualifying campaigns even though they're technically
`graduated` — 12 donors on a campaign that's raised 2% of a $20,000 goal
isn't actually a success yet.

**Screening implication**: fallback-eligible campaigns get the same
screening scrutiny as any other addition — see moderator handbook.
`lowEngagementFlag` specifically should be used sparingly and honestly,
since it has no computed check behind it at all; treat it as a
judgment call worth writing down a reason for (informally, in a
submission note) even though there's no dedicated field for that yet.

Tested end-to-end: added a demonstration campaign (`c008`, 12 donors,
$300 of a $20,000 goal) and confirmed it renders in the TLC section
with "2% of goal reached," while being correctly excluded from the
Success Stories archive.

## Board composition (runs client-side, no server/cron)

The page now renders **three sections** built from the same eligible
pool (not reported, not graduated):

1. **Hero** (1 campaign): prefers a pinned zero-donation campaign, then
   any zero-donation campaign via rotation, then whatever's first
   overall as a last resort. Never appears again in the sections below.
2. **Zero Donations section** (up to 15): all remaining zero-donation
   (`seed`-tier) campaigns not already used as the hero.
3. **TLC section** (up to 10): campaigns with some traction already
   (`first_five`/`first_ten`), kept deliberately separate from the zero
   section since "be someone's first donor" and "help this one over the
   line" are different asks.

Each section is filled by the shared `selectSection(pool, size)`
function: pinned entries in that pool always get a slot, everyone else
rotates through automatically via a date-seeded queue position (same
mechanism as before — the whole pool cycles before repeats, no manual
step or persisted `lastFeatured` write required). **Known limitation
carried over**: because pinned count changes how many slots are open for
rotation, the daily "step size" through the queue isn't perfectly
constant. Not a problem at this scale.

## Pin cap (recommended, not a hard technical limit)

`PIN_CAP = 5`, enforced in `moderator-picker.html`'s star-toggle and
random-pick handlers — blocks pinning a 6th campaign with an
explanatory alert. **The manual override-by-ID field is deliberately
exempt** from this cap, since it's the documented "bypass every filter"
escape hatch for glitches, not a routine picking method. The number 5
is a judgment call (roughly 20% of total board slots), not derived from
anything rigorous — change the constant freely if it's wrong in
practice.

## v28: About, Success Stories, random-campaign widget, embeddable widget

- `about.html` — the origin story (three parts): algorithmic burial of
  zero-donation campaigns, predatory pay-to-play "boost your campaign"
  services, and a real story (This American Life, Ep. 286/588, "The Spy
  Who Loved Everyone" — Improv Everywhere's 2004 "Best Gig Ever" prank
  on the band Ghosts of Pasha) reframed as "same generous impulse,
  without the con." Facts verified via search before writing (band name,
  venue, TAL episode numbers, and the detail that the band later
  performed at Improv Everywhere's own anniversary show — a genuine
  happy-ending detail, not invented).
- `archive.html` ("Success Stories") — lists graduated (10+ donation)
  campaigns from the shared dataset. Recommended and built as a
  low-effort, positive-framing use of data the site already tracks.
- `random-campaign-widget.js` — new shared script, appended to the
  bottom of every public page (after the footer sitemap). Picks a
  genuinely random eligible campaign via `Math.random()` on every page
  load — deliberately NOT date-seeded like the hero/board rotation,
  since this is just incidental exposure, not a fairness-critical
  selection. Requires `board-data.js` loaded first; silently no-ops if
  `campaigns` isn't defined (defensive, in case a future page forgets
  to include it).
- `embed-widget.html` — minimal, iframe-only page (no nav/footer) for
  external sites to embed. Supports `?mode=hero` (today's featured
  campaign) or `?mode=random` (new random pick each load) via URL
  parameter. Verified both modes independently.
- Embed-code generator added to `overlay-generator.html` (Campaign
  Tools page) — a dropdown + copy button producing a ready-to-paste
  `<iframe>` snippet. **`BOOST_BOARD_BASE` in that page's script is a
  placeholder (now confirmed as `https://jiandamonique.github.io/boostboard/`) — update to the real deployed
  URL before publishing**, or every generated embed code will point to
  a nonexistent domain.
- `nav.js` updated with both new pages (About, Success Stories) — full
  page-by-page sweep confirmed all 9 public pages still render nav (9
  links), footer (9 links), and the random widget correctly after the
  change.

## Site structure: landing page + board (v27 restructure)

**No longer one page.** Split into:
- `index.html` — the actual homepage. Just an intro paragraph explaining
  what Boost Board is, and today's hero campaign rendered *large*,
  since nothing else on the page competes with it for attention. Links
  to `board.html` for everything else.
- `board.html` — "The Board." The full three-tier layout that used to
  live on the single page: Zero Donations section (up to 15) and TLC
  section (up to 10). No hero card here — it already lives on the
  homepage — but the tier explanations live here instead, since this is
  where a visitor is actually looking at tiered cards and can connect
  the label to the concept (discovery-model explanation, not an upfront
  FAQ dump).
- `board-data.js` — the campaigns dataset plus `tierOf()`,
  `selectSection()`, `daysSinceEpoch()`, and `computeToday()` (returns
  `{ hero, zeroSection, tlcSection }`), extracted so both pages share
  one source of truth instead of duplicating the dataset and rotation
  math. Both pages load it via a plain (non-deferred) `<script src>`
  tag placed directly before the page-specific inline script that
  consumes it.
- `spotlight-widget-demo.html` (the original combined page) is deleted
  — fully superseded by the split above.

## Automated RSS feed (safe to schedule — no moderation judgment involved)

`generate-rss.js` recomputes the same `hero` selection as `board-data.js`
directly from `campaigns.json` and writes `rss.xml` — one `<item>` per
day, whichever zero-donation campaign is currently featured. Run daily
via `.github/workflows/daily-rss.yml` (scheduled GitHub Action, commits
the regenerated file).

**Why this one's safe to automate, unlike moderation**: it makes no new
decision. It only recomputes a selection from campaigns *already*
approved by a human, deterministically, the same way the client-side
board does. This is a meaningfully different category from the earlier
decision to keep intake/report-resolution manual — those involve
judgment about trust and safety; this is pure recomputation.

**Turning the feed into emails — finalized approach (was open in v27).**
Confirmed via research: GitHub Actions genuinely can send email directly
(SMTP or an email API), no external server needed — the general pattern
is scheduled Action → fetch/recompute → compare against a state file
committed to the repo (to avoid duplicate sends) → call an email
provider's API. Community tools exist for this (`rss-email-digest`,
`rss2email`, `rss-digest`, `rss2newsletter`), but those are built for
**personal digest reading** (one person, their own inbox) — Boost Board
needs the opposite shape: one feed, many external subscribers who
signed up on the site. That needs actual audience/list management, not
a personal feed reader.

**Finalized: native SMTP, two-repo split — not Resend.** Per explicit
preference to avoid a third-party account, the notification pipeline
was rebuilt around plain SMTP (via `nodemailer`) through an email
account already owned (e.g. Gmail with an App Password), rather than a
marketing-email SaaS. Important architectural consequence: **the
subscriber list and notification script now live in a SEPARATE, PRIVATE
repository, never the public site repo.** Reason: `subscribers.json`
contains real email addresses, and GitHub Pages normally requires a
public repo — committing subscriber PII into the same repo as the
public site would expose every subscriber's email to anyone who looked
at the repo or its history.

- **Public repo** (unchanged in this respect): `generate-rss.js` +
  `daily-rss.yml` still produce `rss.xml`, containing only already-
  public campaign data, no PII.
- **Private repo** (`private-notifier-repo/` in this project's working
  files, meant to become its own separate GitHub repo): holds
  `notify-subscribers.js`, `subscribers.json`, its own daily workflow,
  and its own `last-notified.json` state file. Fetches `campaigns.json`
  from the public repo's raw GitHub URL over the network — no repo
  access needed, since that file is already public data — rather than
  checking out the public repo directly.
- Tested against a mock server standing in for the public repo's raw
  URL: fetch succeeds, then correctly proceeds to the SMTP-secrets
  check and fails loudly when they're absent (same fail-loud behavior
  as the Resend version, now applied to missing SMTP secrets instead).
- `INTERNAL_gofundme-campaign-plan.md`'s and this doc's earlier Resend-
  specific content is superseded by this — Resend is no longer the
  plan.

**Still not solved: getting a subscriber's email INTO the Resend
audience in the first place.** `credits.html`'s "Get notified" button
is still a placeholder. Needs either (a) a signup form (Google Form/
Formspree, same pattern as campaign intake) with a manual or
lightly-scripted bridge to Resend's "Create Contact" API, or (b) a
small serverless function that calls Resend's Create Contact API
directly from a client-side form submit (requires somewhere to host
that function — can't be called directly from a static page without
exposing the API key). Not built — needs a decision on which path
before building either.

## "Our goal isn't a sea of $0 campaign pages" (v52, `about.html`)

Directly addresses the v51 finding (zero true zero-donation campaigns
currently in the dataset) as a public-facing philosophy statement, not
just an internal status note: the project isn't trying to collect or
showcase zero-donation campaigns as a category — the actual goal is for
zero-dollar fundraisers to stop existing at all. Frames any campaign
already having a donor by the time it's found or featured (via
submission, sharing, or the platform's own algorithm reacting to that
activity) as the goal arriving early, not a miss. This directly extends
the existing `board.html` transparency note about featured campaigns
possibly already having donations by the time they appear.

**v53 amendment**: clarified that "zero" is shorthand for low activity
generally, not always a literal $0 — the same dynamic applies to
anything submitted through the (future) contact form: it may move past
zero between submission and actually being posted, and that's framed
explicitly as a good outcome, not a discrepancy to explain away.

## SEO / AEO / social sharing meta tags (v36)

Every public page (except `embed-widget.html`, which is `noindex` since
it's only meant for iframe embedding) has: a meta description, a
canonical link, Open Graph tags (title/description/image/url/type/
site_name), and Twitter Card tags. `og:image` and `twitter:image` on
every page point to `standin-image.jpg` (the lotus/hand artwork) as an
absolute URL — social crawlers generally don't execute JavaScript, so
these tags have to be static in each page's raw HTML, not injected by
`nav.js` the way the nav bar is.

`index.html` additionally has a JSON-LD `WebSite` structured-data block
for AEO (answer-engine optimization — helping AI-powered search/answer
tools understand what the site is, distinct from traditional SEO).

**If a page's title or URL ever changes, its meta tags need manual
updating too** — they're static per-page, not derived from anything.

## Blog (v36)

- `blog.html` — public index, lists posts from a `posts` array (empty
  by default, shows "Nothing posted yet" rather than fake placeholder
  entries). Same shared nav/footer/widget pattern as every other page.
- `blog-composer.html` — the actual WYSIWYG tool. `noindex`, not linked
  from the main nav (linked only from `blog.html` itself), since it's a
  content-creation tool, not a page visitors should land on. Uses a
  plain `contenteditable` div with `document.execCommand()` for
  bold/italic/headings/lists/links/images — no external rich-text
  library, consistent with the zero-dependency approach everywhere else
  on this site. Has Byline (defaults to "Volunteer Team," editable per
  author) and Date (auto-fills to today, editable) fields; both render
  as a dateline under the post title in generated output.
- Workflow: write in the composer, click "Generate blog post HTML" (auto-
  fills a URL-safe filename from the title, embeds matching SEO/OG tags
  using the post's own title/description, includes the shared nav/
  footer/widget scripts), copy or download the result, upload it as a
  new file in the repo, then add one line to `blog.html`'s `posts` array
  linking to it.
- **First real post published**: `why-boost-board-exists.html` — an
  adaptation of `about.html`'s three-part origin story into blog voice,
  byline "Volunteer Team," dated 2026-09-07. Added to `blog.html`'s
  `posts` array. This sets the precedent that individual future authors
  can use their own byline in the composer's Byline field rather than
  the default.
- Tested end-to-end: title→filename slug generation, HTML generation
  preserving formatted content, byline/date rendering, and confirmed
  the blog index correctly lists and links to the real post with its
  date shown.

## Claude-assisted campaign entry — now the active workflow

As of this session, real campaign data is being added by pasting raw
information into a Claude conversation and having Claude structure it
into the schema, replacing the placeholder sample campaigns directly in
`campaigns.json` (and keeping the other two inline copies — `board-
data.js` and `moderator-picker.html` — in sync, verified by counting
entries, not just checking syntax, per the v33 lesson).

## Moderators' Picks (`mods.html`)

Deliberately separate from the daily rotation system entirely — no
`tierOf()`, no `selectSection()`, no date-seeding. Just a plain
hardcoded `modsPicks` array a moderator edits by hand, meant for
campaigns the team wants to keep visible indefinitely rather than
cycling through a queue. Empty by default with an honest empty state.
Moderators are not named anywhere on this page by design — the page is
about the campaigns, not about who picked them.

## "How you can help" + hashtag guidance (`credits.html`, v49)

`credits.html` doubles as the site's donate/support page — there's no
separate `donate.html`. Added a "How you can help" section up top,
broadening the ask beyond money (give to today's featured campaign,
signal boost/share, submit a campaign, support the app), and a
"Sharing with a hashtag" section distinguishing an owned tag (`#Boost
Board`, still building an audience) from established tags with real
existing communities (`#SignalBoost`, `#MutualAid`, `#GoFundMe`,
`#PayItForward`, `#CommunitySupport`) — chosen for having genuine active
audiences already, not just plausible-sounding options.

## Newsletter framing (`credits.html`)

Deliberately not framed as a newsletter in the conventional sense — no
roundups, no product updates. One email per zero-donation feature,
nothing else. Named plainly ("Get an email when someone needs a first
donation" / "Get notified") rather than branding it, consistent with the
no-cute-branding rule.

## Homepage hero (internal name: "Inbox Zero" — never used in public copy)

The homepage (`index.html`) pulls one campaign to feature large — as of
the v27 restructure, this is now the *entire content* of the hero
section on its own page, not competing with a grid below it. Internally
this mechanism is called "Inbox Zero" — clean shorthand for a campaign
with a completely empty donation history — but the public-facing label
is always the plain "Today's featured campaign." No cute or clever
branding on anything user-facing, per standing direction.

- As of v39, hero preference is: **any pinned campaign, regardless of
  tier** (not just pinned+seed as before) → seed-tier via rotation →
  any eligible campaign as a last resort. Changed because a moderator
  pinning a specific real campaign (e.g. a genuine person they want
  front and center) is a stronger, more deliberate signal than the
  tier system's automatic seed-tier preference — the old logic would
  have ignored a pin on a non-zero-donation campaign entirely for hero
  purposes, even though pinning is supposed to represent an explicit
  override.
- As of v27, the hero is computed by `computeToday()` in the shared
  `board-data.js`, called independently by both `index.html` (renders
  the hero) and `board.html` (only uses `hero.id` to exclude it from the
  grids and `hero.link` for the "donate to today's featured campaign"
  button — never re-renders the hero card itself).
- **The "Do you see a donation here? Woo hoo!" pitch copy is durable by
  design**: it lives in `index.html`'s code as a rule (`if the hero's
  tier is seed, show this`), not stored per-campaign in
  `campaigns.json`. It has zero dependency on which specific campaign
  is hero — adding, removing, or replacing campaigns can never erase
  it, since it lives in a completely separate file from the data. The
  only way it disappears is a direct code edit to that line.
- If a campaign is both pinned and seed-tier, it's very likely to be the
  hero, since pinned entries are guaranteed a slot and seed-tier is
  preferred for the hero. This is intentional: it lets a moderator
  effectively choose tomorrow's hero by pinning a specific zero-donation
  campaign today.

### Naming ideation log (internal concept name only, not public copy)

Running list from workshopping sessions — none of these are meant for
public use, just to settle on the clearest internal shorthand:
- "Inbox Zero" (current) — clean-slate/no-activity-yet meaning lands
  well, slight mismatch since "inbox zero" usually implies organized/
  cleared rather than "hasn't started."
- "Zero to Hero" — rejected, too cutesy.
- "The Zero Spot" — plainer, keeps "zero" as the anchor.
- "Ground Floor" — investment-adjacent framing, "get in before anyone."
- "Clean Slate" — closest cousin to Inbox Zero's meaning without the
  inbox-specific baggage.
- "First Look" — plain, neutral, no metaphor to get slightly wrong.
Open — revisit whenever it comes up again.

## Repo placement: admin tools are private, not part of the public site (v59)

**Decision: `moderator-picker.html` and `blog-composer.html` live in the
private notifier repo (`admin-tools/` folder), never in the public
`boostboard` repo.** Both were originally bundled with the public site
files, which was a mistake worth writing down so it doesn't happen again
with some future internal tool.

**Why it matters, not just tidiness:** a public GitHub repo's source is
public-facing copy, full stop — "not linked from the nav" is not the
same as private. `moderator-picker.html`'s own code documents exactly
which report answer is allowed to hide a campaign (see Report Handling
below), which directly violates the "never document this exact
mechanic in any public-facing copy" rule if the file sits in a public
repo. `blog-composer.html` has no equivalent secret to protect, but it's
genuinely internal-only tooling (already marked `noindex, nofollow`),
so the same placement applies for consistency.

**Neither tool needs to be hosted anywhere.** Both are self-contained
HTML/JS with no backend calls beyond an optional AI parse — paste,
parse, download a file. Open them as local files after cloning the
private repo. No GitHub Pages, no server, no second embed URL to keep
in sync.

**Rule going forward**: before adding any new internal-only tool file,
ask "does this need to be network-reachable by the public?" If no, it
goes in the private repo's `admin-tools/` folder, not the public site
files.

## Manual override paths (moderator-picker.html)

- **Random pick**: filters to a tier, excludes `reported` and anyone with
  `lastFeatured` within `RECENCY_GUARD_DAYS` (currently 7, hardcoded — see
  the picker's `<script>`), then picks uniformly at random from what's
  left. On pick, sets `pinned: true` and `lastFeatured: today`.
- **Manual override by ID**: same effect, bypassing tier/recency filters
  entirely — this is the "something glitched, force it now" escape hatch.
- Both paths produce a downloadable updated `campaigns.json` — there is no
  auto-publish; a human commits/uploads the result.

## Report handling

`reported: true` is a hard filter applied before pin logic in the board
build, so a reported campaign disappears from public view immediately on
next publish regardless of its pin/tier status. Clearing it is a manual
toggle in the picker. No auto-expiry on reports currently — a stale
`reported: true` will hide a campaign indefinitely until a moderator
looks at it, which is the intended fail-safe (fail closed, not open).

**Never document this exact mechanic in any public-facing copy.** The
"report instantly hides a campaign, even a pinned one" rule is real and
correct, but explaining it publicly hands a bad-faith reporter a precise
recipe for suppressing a campaign they don't like. Public copy should
say only that reports get reviewed by a moderator.

**Two different report categories, now distinguished in the picker (v58).**
The public "Report / Update" link covers two genuinely different
situations:
1. **A concern** (scam, inappropriate content, etc.) — should trigger
   the instant-hide behavior above.
2. **"This campaign already has donations now"** or similar informational
   update — should NOT hide the campaign, just prompt a moderator to
   update `donationCount`. Treating this the same as a concern report
   would incorrectly hide perfectly good campaigns just because someone
   helpfully flagged a stale number.

**How it's actually built — plain-language version.** There is only
*one* intake form (no separate report form — see the decision note
below). That one form opens with a required "What's this about?"
multiple-choice question: "A new campaign to submit" / "A concern about
a listed campaign" / "This campaign already has donations, please
update" / "Something else." Whatever a person picks becomes the answer
to that one question in the pasted response.

When a moderator pastes any response into `moderator-picker.html`'s
single paste box, `classifyReason()` reads that one answer and decides
what to show:
- **"New campaign"** (or a blank/missing answer, for old-format
  responses from before this field existed) → the ordinary
  add-a-campaign form, unchanged from before.
- **"Concern"** → the report-result panel: it looks up the campaign by
  matching the pasted "Campaign name" against `campaigns` (exact
  match first, loose substring match as a fallback), shows a red
  "concern" badge, and enables a **"Mark reported"** button. Nothing is
  hidden until a human clicks that button — `classifyReason()` only
  *labels* the report; a person still has to act on it.
- **"Already has donations"** → same lookup and badge (colored
  differently), but the button copy and the note both say this is
  informational only — the moderator should hand-edit `donationCount`
  in the table, not mark it reported.
- **"Something else"**, or a name that doesn't confidently match any
  campaign → shown as-is with a note to eyeball it and decide by hand;
  the tool never guesses when it isn't confident.

**Decision note (superseding an earlier plan): one form, not two.**
An earlier version of this plan called for building a second, dedicated
Google Form just for reports, with its own embed URL and a pre-filled
"Campaign ID" parameter passed from the report link on `board.html`.
That was scrapped as unnecessary complexity — same information, same
routing outcome, twice the moving parts (two forms to keep in sync, two
embed URLs, a pre-fill parameter to wire up). The single-form version
above gets the same result — human-reviewed, only "concern" can hide a
campaign — using one question added to the form that already exists,
and name-matching instead of a dedicated ID field.

## Intake (not yet built)

Planned: embedded form (Google Form/Formspree) on the public site,
landing in a spreadsheet/inbox a moderator reviews before manually adding
an entry to `campaigns.json`. This step is intentionally never automated
— see the moderator handbook for why.

## If this becomes a real product later

Things that would need to change first:
- Move off a single hand-edited JSON file to a real datastore with
  concurrent-write safety and an audit trail of moderator actions.
- Persist the rotation cursor explicitly instead of the date-modulo
  trick, so the "known limitation" above goes away.
- Move intake off a third-party form service to something you control,
  if data volume or sensitivity outgrows what a Google Form/Formspree
  free tier is comfortable holding.
- Add real authentication for moderators instead of "whoever has the
  file."
