# INTERNAL — Frontend / Look & Feel
(Never commit this file or this folder to GitHub.)

## Design tokens (from the existing artist-directory site, carried forward)

```
--cream:  #f2f7f2   background
--warm:   #e6efe6   secondary surface (tags, hover states)
--deep:   #162418   primary text, buttons
--muted:  #5c6b5c   secondary text
--border: rgba(40,80,45,0.18)
--shadow: 0 4px 24px rgba(22,36,24,0.08)
```

Tier/status accent colors, additive:
```
--t-seed:      #9b6e9e   (seed tier)
--t-five:      #7193a4   (first five tier)
--t-ten:       #6b9e8a   (first ten tier)
--pin:         #b5762c   (editor's pick)
--report:      #b23b3b   (reported/flagged, moderator view only)
```

Typography:
- **Lora** (serif) — headings, campaign names. Chosen for warmth over the
  clinical feel a sans-only UI would have, given the emotional weight of
  what's being displayed.
- **Source Sans 3** — body text, descriptions.
- **JetBrains Mono** — small labels, eyebrows, tier badges, tags. Used
  deliberately for anything "system-generated" (tier, status) to visually
  distinguish it from human-written content (name, description) — a
  quiet signal to the reader about what's editorial vs. automated.

## Card anatomy (public board)

1. Eyebrow (mono, colored by tier OR "Editor's Pick" in `--pin` if pinned)
2. Name (Lora, serif)
3. Description (Source Sans, 2-3 lines max in practice — keep submissions
   short at intake or the card overflows)
4. Community tags (mono, pill-shaped, muted)
5. Actions row: primary CTA button (View campaign) + Report link
   (deliberately de-emphasized — smaller, underlined text, not a button —
   so it's available but not the visual focus of the card)

Pinned cards get a colored left/full border (`--pin`) as the only
structural difference from a regular card — deliberately subtle, so
"Editor's Pick" doesn't look like an ad or a sponsored placement, just a
quieter form of emphasis.

## Moderator tool visual language (internal use, not public-facing polish)

Table-based rather than card-based — optimized for scanning many entries
quickly, not for persuasion. Color coding:
- Pale gold row background = pinned
- Pale red row background + reduced opacity = reported (visually
  "receding" to reflect its hidden status)
- Italicized name = recently featured (within recency-guard window),
  signals "don't bother picking this one right now" at a glance

## Accessibility notes

- Never rely on color alone: tier badges carry text labels (`seed`,
  `first_five`, etc.), not just color.
- Avoid CAPTCHA-style challenges on the public intake form — classic
  distorted-text CAPTCHAs are a known barrier for visual/cognitive/motor
  disabilities, which is a real risk given who this serves. Prefer a
  honeypot field + manual review instead, or Cloudflare Turnstile if
  something stronger is needed.
- Keep description text short and plain-language by default; this is a
  design constraint worth enforcing at intake (a character limit on the
  submission form), not just a style preference.

## If this becomes a real product later

Worth commissioning proper illustration/iconography instead of relying on
color-coded dots and mono-font badges — the current system reads as
"functional prototype," which is appropriate for a demo but not for a
funded launch. A style guide with actual brand identity (not just
inherited tokens from the artist-directory site) would be a reasonable
early design spend.
