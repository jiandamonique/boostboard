# INTERNAL — Changelog
(Never commit this file or this folder to GitHub. Living document —
add a new dated entry every time something meaningfully changes, going
forward from here.)

Format: newest entry at the top. Each entry = date, what changed, why.

---

## 2026-09-06 — v58: Report/Update wired to submission page, urgent-need hashtag note added

**Changed:**
- `board.html`: updated the app-disclaimer paragraph per exact request
  ("only signal boosts donations randomly, as submitted or brought to
  our attention," replacing "doesn't touch anyone's donations").
- **Report/Update is no longer a demo alert()** — it now redirects to
  `submit.html?report=<id>&name=<campaign name>`. `submit.html`
  detects those params, retitles itself "Report / Update a Campaign,"
  and shows a banner naming the specific campaign, pointing to a
  freeform "Anything else?" field as the actual reporting mechanism —
  avoiding a full form rebuild with branching logic. Tested both paths:
  a plain visit still shows the normal submission framing; a
  report-flagged visit correctly shows the reported campaign's name.
  **One manual step still needed on your end**: add that one optional
  freeform question to the live Google Form itself — can't be done via
  chat since it requires editing the form directly in your Google
  account.
- Added a third `page-note` paragraph acknowledging urgency directly:
  suggesting `#BoostBoard` or `#SignalBoost` on social media for anyone
  who can't wait on the review queue, with a plain apology for not
  having staff to respond to urgent needs in real time.

**Why:** Direct requests — a wording change, a real (not just proposed)
fix for the report button reusing existing infrastructure rather than
building new form logic, and an honest acknowledgment that some
situations can't wait for manual review.

---

## 2026-09-06 — v57: Jaye unpinned (rotation confirmed live), two board.html text edits, alignment pattern established

**Changed:**
- **Unpinned Jaye (`c001`)** per explicit confirmation. Verified with
  the actual rotation math (not a guess): today's hero is now "Paint
  Liverpool Better," tomorrow's will be "Helping a Family Rebuild After
  Firework Tragedy" — confirmed against the live rendered site, which
  matched the manual calculation exactly. Rotation index shifts by
  exactly one each calendar day, so a different real campaign is
  featured daily going forward.
- `board.html`: updated the first `page-note` paragraph to the exact
  requested text (fixed an apparent typo, "Tot hat end" → "To that
  end"). Updated the second `page-note` paragraph's Report/Update
  sentence, smoothing a small grammatical redundancy in the requested
  text ("please use the X link... is the easiest way" had two competing
  action-framings) into one coherent sentence while keeping the
  requested "something that looks off" phrasing.
- **Established an alignment pattern**: titles, headings, and short
  one-line badges/captions stay centered; longer body paragraphs
  (multi-sentence explanatory text) switch to left-aligned, since
  centered text is measurably harder to read past a sentence or two.
  Applied to `board.html`'s two `page-note` paragraphs and to
  `index.html`'s `.hero-desc` (a campaign's actual description text) —
  found and fixed the same rule as dead/unused CSS on `board.html`
  itself, where the hero card never actually renders.
- This interpretation was stated explicitly in conversation and not
  yet confirmed — if it doesn't match what was meant, revisit before
  extending the pattern to other pages.

**Why:** Direct edits plus an important behavioral confirmation
(rotation genuinely works now that the pin is gone) proven with actual
math against the live site rather than asserted from the code alone.

---

## 2026-09-06 — v56: Paragraph/heading spacing increased across content pages, CTA idea logged

**Changed:**
- Fixed real cramped-text issue: `credits.html` had **no spacing rule
  at all** for plain `<p>` tags (a full CSS reset with nothing filling
  margins back in), which is exactly why its newer sections read as one
  dense block. Added a proper paragraph rule and increased heading
  margins there.
- Increased heading/paragraph spacing on `board.html` (the example
  given), `about.html`, `helpful-fundraising-ideas.html`,
  `roadmap.html`, and `emergency-help.html` — headings now get real
  breathing room above them (roughly doubled top margins), paragraphs
  get more room below.
- Logged four rephrased (not copied) CTA line options — adapted from
  GFM's own "Become an early supporter / Your donation matters"
  pattern — into the internal roadmap as a content backlog item for
  gradual use, per explicit "over time" framing rather than building a
  rotating-CTA system now.
- Flagged directly in conversation (not yet acted on, pending answer):
  Jaye is currently pinned, so she'll remain hero indefinitely, not
  just today — pins don't auto-expire. Genuine daily rotation among
  the 10 real campaigns would require unpinning her first.

**Why:** Direct spacing complaint, traced to an actual missing CSS rule
rather than just a "add more margin" guess — worth knowing which pages
had zero paragraph spacing by omission versus which just had it too
tight.

---

## 2026-09-06 — v55: Footnote asterisk added linking the TAL story to its source

**Changed:**
- `about.html`: shortened heading "3. A story about giving someone a
  good day, the hard way" → "3. A story about giving someone a good
  day," and added a footnote-style asterisk after "story" in that
  heading, paired with a matching asterisk at the start of the existing
  "You can hear the full story yourself at thisamericanlife.org"
  paragraph — a plain textual footnote pointing a reader to the source
  episode. Verified via headless execution both asterisks render
  correctly.

**Why:** Direct edit request — a lightweight, conventional footnote
marker connecting the story reference to its actual source without
adding a full citation apparatus.

---

## 2026-09-06 — v54: About page trimmed — labels removed, one section cut, heading reworded

**Changed:**
- Removed the "This started from three things." lead-in line and "The
  simple version" heading from `about.html` — the flashlight/bulletin-
  board explanation now flows directly from the page intro straight
  into the numbered reasons, with no label in between.
- Removed the entire "Why a computer can't just find these for us"
  section (the automated-search-limitation explanation) from the
  public page.
- Renamed "Our goal isn't zero-dollar pages" → "Our goal isn't a sea of
  $0 campaign pages." Content beneath it unchanged.
- Verified via headless execution: page still renders cleanly, correct
  section order (three numbered reasons → the renamed goal section → A
  personal note), nav still intact at 14 links.

**Why:** Direct edit requests — page trim and one heading reword, no
content-logic changes, just tightening what's shown.

---

## 2026-09-06 — v53: "Zero" clarified as shorthand for low activity, not always literal $0

**Changed:**
- Amended the "Our goal isn't zero-dollar pages" section on `about.html`
  with a clarifying line: "zero" is used as shorthand for low activity
  generally, not always a literal $0 figure. Explicitly connects this to
  the contact form specifically — a campaign submitted there may no
  longer be at zero by the time it's actually posted, and that's framed
  as a good outcome, consistent with the section it extends.

**Why:** Direct amendment request, tightening the philosophy statement
to be accurate about what "zero" actually means in practice across the
site (donation count tiers, fallback eligibility by percent-of-goal,
etc.) rather than implying a strict literal-dollar reading.

---

## 2026-09-06 — v52: "Our goal isn't zero-dollar pages" added to About

**Changed:**
- Added a new About page section directly addressing the v51 finding
  (zero true zero-donation campaigns currently in the dataset) as a
  stated project philosophy: Boost Board isn't trying to advertise or
  collect zero-donation campaigns as a category, and a campaign already
  having a donor by the time it's found or featured — whether from
  submission activity, sharing, or a platform's own algorithm reacting
  to that — counts as the actual goal (no zero-dollar fundraisers)
  arriving early, not a miss. Verified via headless execution that it
  renders in the correct position (after the origin reasons, before the
  personal note).

**Why:** Direct request to discuss this reframe publicly rather than
just internally — turns a data-status finding into an explicit,
public commitment about what the project is actually trying to
achieve.

---

## 2026-09-06 — v51: Last placeholder replaced (100% real data), GFM Pro clarified, hero-pitch durability documented

**Changed:**
- Replaced the last remaining sample entry (`c005`, Diego) with a real
  campaign: a family recovering from a July 4th firework explosion that
  caused home damage and left a family member in critical condition
  (4 donors, $430 of $5,000). **The dataset is now 10 of 10 entries
  real, zero placeholder data left.**
- **Consequence worth flagging plainly**: this means zero true
  zero-donation (seed-tier) campaigns currently exist in the dataset —
  the exact case Boost Board exists for. Tested and confirmed the site
  degrades gracefully (Zero Donations section shows a clean "No other
  zero-donation campaigns right now" message, hero still correctly
  shows the pinned campaign via the existing pin-always-wins logic) —
  nothing broke, but this is now the top sourcing priority, flagged as
  such in the roadmap.
- Synced all three dataset copies, verified by counting all 10 IDs in
  each per the standing v33 lesson.
- **Verified before writing**: GoFundMe Pro (formerly "Classy") is a
  completely separate enterprise nonprofit product (~$299/month), not a
  paid tier of personal GoFundMe accounts — confirmed via direct
  research rather than assumed. Also confirmed regular personal
  campaigns already natively support recurring monthly donations (5%
  fee to the donor, free for the organizer, not available in every
  region yet). Documented both in the internal roadmap with the
  practical takeaway: nothing to build differently, but worth knowing
  for outreach conversations.
- Explicitly documented (previously undocumented) that the "Do you see
  a donation here? Woo hoo!" pitch copy is durable by design — lives as
  a rule in `index.html`'s code, not tied to any campaign's data, can't
  be erased by normal moderation.

**Why:** Continues real-data replacement to completion, catches and
surfaces a real consequence of that completion (no zero-donation
campaigns left) rather than letting it pass silently, and verifies
platform-specific claims about GoFundme Pro before writing them into
internal planning, consistent with the standing practice established
after the Buttondown pricing mistake earlier in this project.

---

## 2026-09-06 — v50: "Not the donation Olympics" line added to Credits page

**Changed:**
- Added a short line to `credits.html`, right after the "How you can
  help" list: donors have their own reasons, and every form of help
  (signal boosting, donating, sharing) is respected equally — no
  ranking implied between them.

**Why:** Direct request, placed where it naturally reinforces the
adjacent "How you can help" section's already-equal framing of the
different ways to contribute.

---

## 2026-09-06 — v49: "How you can help" and hashtag guidance added to Credits page

**Changed:**
- Confirmed there's no separate donate page — `credits.html` already
  serves that role, so expanded it rather than building a new page.
- Added "How you can help," broadening the ask beyond donating money:
  giving directly to today's featured campaign, signal-boosting/sharing,
  submitting a campaign, or supporting the app itself.
- Added "Sharing with a hashtag" with a curated list, distinguishing an
  owned tag (`#BoostBoard`, still building an audience) from
  established tags with genuine existing communities
  (`#SignalBoost`, `#MutualAid`, `#GoFundMe`, `#PayItForward`,
  `#CommunitySupport`) — chosen for real reach, not just plausibility.
- Verified via headless execution that both new sections render in the
  correct position, ahead of the existing app-support content.

**Why:** Direct request — "how you can help" language plus hashtag
suggestions, delivered on the page that was already functionally the
donate page rather than fragmenting into a new one.

---

## 2026-09-06 — v48: Plain-language "simple version" added to About page

**Changed:**
- Added "The simple version" to `about.html`, right after the intro and
  before the three origin reasons — a school-bulletin-board/flashlight
  analogy explaining the mechanism (algorithms favor what's already
  popular, volunteers spotlight one overlooked campaign daily, turns
  rotate fairly, money is never touched) before getting into the why.
  Verified via headless execution that it renders in the correct
  position in the page's section order.

**Why:** Direct suggestion evaluated on merit — the analogy fills a real
gap the existing About page didn't cover: a quick mental model of *how*
the mechanism works, before the *why* origin story. Fits the
accessibility-first, plain-language standard already established
elsewhere on the site.

---

## 2026-09-06 — v47: GFM campaign copy finalized, two real corrections to pasted guidance

**Changed:**
- **Verified two claims from a pasted GoFundMe-ToS guide before trusting
  them.** Confirmed accurate (checked GFM's own support documentation
  directly): organizers may not offer any good or service in exchange
  for a donation, full stop — stronger than "not required," it's
  prohibited outright, which corrects our own earlier reward-tier
  brainstorm (stickers, badges) that had drifted over from the
  Indiegogo-era planning. Found likely inaccurate: the "Creative & Tech
  / Community" category names in the same guide — GFM's actual live
  category list (Medical, Memorial, Emergency, Education, Nonprofit,
  Animals, "See more") doesn't show those; that naming appears to be
  bled over from Indiegogo's real categories instead. Documented both
  findings with sourcing.
- Confirmed as standard, expected practice: donations exceeding the
  stated goal going toward ongoing maintenance — GFM doesn't cap
  fundraising at the goal, it's a progress marker only.
- **Finalized the actual campaign copy** — full title, description
  (using the real funding-worksheet numbers), and a ~150-word LinkedIn
  blurb, all written out ready to copy-paste once the campaign is
  created. Marked done on the pre-launch checklist.

**Why:** Direct request for GFM campaign coaching plus a shareable
blurb — handled by verifying the pasted ToS guidance against GFM's own
current documentation rather than accepting it at face value, catching
one real correction (reward tiers) that would have created an actual
ToS problem if left uncorrected.

---

## 2026-09-06 — v46: Second blog post published, location-search sourcing tip added

**Changed:**
- Published `how-fundraisers-get-found.html` — an original rewrite (not
  reproduced) of the general ideas in a submitted article about how
  people locate GoFundMe pages: platform search, external search
  engines, social sharing, privacy settings (Public/Private/Friends &
  Family), and direct links. Deliberately left out several quotes in
  the source material attributed to an unnamed "GoFundMe spokesperson"
  and "digital marketing specialist," since those can't be verified as
  real and shouldn't be presented as fact. Reframed the whole piece
  around Boost Board's actual angle: every discovery path favors a
  campaign that already has momentum, which is the gap the board exists
  to help with.
- Added GoFundMe's native "fundraisers near you" location-filter search
  to the moderator handbook's sourcing techniques, with the same caveat
  as other search paths — it narrows by location but still favors
  already-active campaigns.
- Added to `blog.html`'s posts array (now 2 real posts, newest first).
  Tested: both posts display correctly, and the new post's own page
  renders with correct nav and byline.

**Why:** Direct request for a blog rewrite of the submitted article,
handled carefully given the source material's unverifiable quotes, plus
a genuinely useful sourcing technique addition for the internal
handbook.

---

## 2026-09-06 — v45: Seven more real campaigns added, dataset now 9/10 real

**Changed:**
- Extracted and added 7 more real campaigns from uploaded `.mhtml`
  files: Simba (emergency vet care), Jimmy Morgan (Jamaica Rugby League
  travel costs), Paint Liverpool Better (community project), Give a Dog
  a Second Chance (rescue programme), Eloise/Philippines children's
  education (pageant-linked fundraiser), a family in crisis after
  workplace bullying, and Aubry's ORU tuition fund. Replaced the 5
  remaining sample entries (`c002`–`c004`, `c007`–`c008`) and added 2
  new ones (`c009`, `c010`) — dataset is now 9 of 10 entries real, only
  `c005`/Diego remains sample data.
- Extracted each campaign's real photo the same confirmed way as
  before — pulled directly from each `.mhtml`'s embedded `og:image`
  match, not hotlinked.
- **Aubry's campaign (30 donors, 23% of a $6,500 goal) correctly
  graduates under the existing tier logic** — well past the fallback
  threshold (needs <10% to qualify as fallback), so it's a genuine
  success case, not a struggling one. This is the site's first real
  entry in the General Archive, replacing what had been sample data
  there.
- **Caught and fixed a real bug while writing the update script**: a
  Python sequencing error (`c.clear()` called before re-reading `c['id']`
  to look up its replacement) threw a `KeyError` on the first attempt —
  fixed by capturing the id in a variable before clearing. Caught
  immediately since the script errored out before writing the file, so
  `campaigns.json` was never at risk of corruption.
- Synced all three dataset copies (`campaigns.json`, `board-data.js`,
  `moderator-picker.html`'s two internal copies) using the precise-anchor
  method, verified by counting all 10 IDs in every copy — not just
  checking JS syntax, per the standing v33 lesson.
- Tested end-to-end: confirmed hero (Jaye), Zero Donations section
  (Diego only), TLC section (7 real campaigns), and General Archive
  (Aubry) all render correctly with the expanded real dataset.

**Why:** Continues real-data replacement toward a fully live dataset;
the Aubry case is a good organic demonstration that the tier/fallback
system correctly distinguishes "graduated because it succeeded" from
"technically past 10 donors but still struggling," which was the whole
point of building the fallback pathway in the first place.

---

## 2026-09-06 — v44: Live-site staleness caught, docs audit, about.html status paragraph

**Changed:**
- **Tested the actual live contact form directly** by fetching it — the
  Google Form itself is live and fully functional (all six fields
  present, no sign-in required). In the process, also fetched the live
  homepage and found it's showing pre-v40 copy — confirming the public
  `boostboard` repo hasn't been re-uploaded since an early point in this
  session, despite many rounds of file changes since. Flagged at the
  top of the pre-launch checklist as the first thing to fix, since
  everything else documented here is only true once the live files
  actually match.
- Ran a documentation audit: found `roadmap.html`, `blog.html`,
  `blog-composer.html`, and `mods.html` were missing from the
  operations doc's file-by-file walkthrough (built after that section
  was last updated). Added all four. Added a dedicated "Moderators'
  Picks" section to the backend architecture doc, previously only
  mentioned in the changelog.
- Confirmed public pages don't leak internal-only mechanics (the
  pin-always-wins-hero rule, fallback eligibility internals) — checked
  directly rather than assumed.
- Added a status paragraph to `about.html`: volunteers have been
  hand-selecting campaigns to boost since there's no inbound submission
  pipeline yet, and will continue to hand-select if submissions are
  slow or absent once the pipeline exists.

**Why:** Direct request to test the form and audit documentation
consistency — the audit caught a real gap (four undocumented pages) and
the live-site test caught something more consequential (the deployed
site being out of sync with everything built since), both worth
surfacing rather than assuming "we built it, so it must be true
everywhere."

---

## 2026-09-06 — v43: About page additions, Moderators' Picks page, secrets vs. environments clarified

**Changed:**
- Added "A personal note" to `about.html` — acknowledging, without
  identifying specifics, that some volunteers are personally going
  through hard times and this project grew partly out of choosing to
  turn that into something useful. Also added a plain "we're under
  construction, DIY/volunteer-run, tell us about bugs" line.
- Built `mods.html` ("Moderators' Picks") — ongoing campaigns the
  moderator team wants to keep visible outside the daily rotation,
  intentionally not time-bound (no rotation logic, manual array,
  moderators stay anonymous by design). Empty by default with an
  honest empty state. Added to `nav.js` (14 pages total).
- Logged the duplicate-email-field note from the live Google Form into
  `INTERNAL_roadmap.md`'s current-functionality list, not just chat.
- Clarified in conversation (not yet needing a doc change) the
  difference between GitHub's Environments feature (named, scoped
  secrets — not referenced by our workflow) and plain repository
  secrets (what's actually needed) — likely source of the "BOOSTY"
  naming confusion.
- Flagged a real security consideration: an App Password was typed
  directly into this chat session. Advised treating that copy as less
  private going forward, with an easy no-pressure option to revoke and
  regenerate. Recommended against storing credentials in internal docs
  (which get bundled into shared zips) in favor of a real password
  manager, or simply relying on GitHub Secrets as the actual storage
  once entered there.

**Why:** Direct content requests plus real setup confusion worth
resolving precisely (environments vs. secrets) and a security nudge
worth surfacing the moment it came up rather than letting it pass
silently.

---

## 2026-09-06 — v42: Real Google Form embedded, SMTP secret-naming and app-password troubleshooting

**Changed:**
- Real Google Form embedded in `submit.html`, replacing the placeholder
  — confirmed by fetching the live form directly that it doesn't
  expose the owner's account email to respondents. Noted a minor
  redundancy (duplicate email field) as an optional cleanup, not a bug.
- Documented the GitHub Secrets naming requirement explicitly after a
  real mix-up: each secret's Name field must be exactly `SMTP_HOST`,
  `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, or `FROM_EMAIL` — a
  differently-named secret (e.g. a personal nickname for the secret)
  won't be found by the script, since lookup is by exact name.
- Documented the App Password flow in full: requires 2-Step
  Verification enabled first (confirmed via search this is still
  accurate), generated at myaccount.google.com/apppasswords, shown only
  once.

**Why:** Real setup friction hit in practice — a secret named
"BOOSTY" instead of one of the five required names, and uncertainty
about what belongs in `SMTP_PASS`. Both now documented as concrete
troubleshooting, not just answered once in chat.

---

## 2026-09-06 — v41: Credits page transparency note moved internal, roadmap status updates, empty-repo troubleshooting

**Changed:**
- Removed "Where this is headed" (the future-financial-transparency
  note) from the public `credits.html` — moved into
  `INTERNAL_roadmap.md`'s open-questions section instead, since
  committing to that level of public reporting isn't appropriate to
  promise before it's actually true.
- Updated `INTERNAL_roadmap.md` with current status: 2 of 8 sample
  campaigns replaced with real ones so far, image-extraction-from-
  `.mhtml` confirmed and ready to reuse without re-verifying feasibility
  each time, 4 more real campaigns still needed for the board page.
- Added an "I created the repo but it's empty" troubleshooting entry to
  the setup guide — creating a repo and uploading files are two
  separate steps, easy to think the first one finished the job.

**Why:** Keeps the public credits page from promising a level of
transparency not yet true, and captures real-time setup friction
(private repo created successfully but not yet populated) as a
documented, reusable troubleshooting case rather than a one-off answer.

---

## 2026-09-06 — v40: Copy edits across five pages, submit page + nav CTA, broken QR image fixed

**Changed:**
- `about.html`: revised the "why a computer can't just find these" ending
  to mention the intake process as the other way campaigns get found
  (people notifying us), not just manual searching. Deleted the entire
  "What we took from that" section per request.
- `roadmap.html`: replaced the two opening paragraphs with warmer,
  more open wording (welcoming feedback, pointing to issues/contact)
  and a tighter statement of current focus; the "bigger questions still
  open" paragraph was dropped as part of the requested replacement text.
- `helpful-fundraising-ideas.html`: added a closing bullet, kept as close
  to verbatim as possible, acknowledging that sometimes there's no
  capacity for more than posting the page or having someone else post
  it, with no pressure attached.
- `overlay-generator.html`: fixed a real bug — the QR code `<img>` had
  no `src` before a link was entered, showing a broken-image icon by
  default. Now hidden (`display:none`) until a real link exists, then
  shown. Also changed "QR code to your fundraiser" → "QR code for your
  fundraiser" per request.
- `credits.html`: replaced the "Thanks to" list per exact provided
  text, including four blank list items reserved for future names to
  be added directly.
- Built `submit.html` — a submission page with a clearly-marked
  placeholder where the real Google Form's embed `<iframe>` code goes
  once built (exact steps given in chat and cross-referenced to the
  existing Google Form setup section). Added "Share Your Page" as a
  nav CTA linking to it.
- Tested: QR image correctly hidden/shown before and after a link is
  entered; `submit.html` renders with correct nav (13 pages) and active
  state.

**Why:** Batch of direct copy/content requests plus a genuine bug fix
(the QR placeholder) surfaced while making the requested wording change
on the same element.

---

## 2026-09-06 — v39: First real campaigns added, hero logic changed to pin-always-wins, masthead image

**Changed:**
- **Replaced two sample campaigns with real ones**, extracted from
  uploaded `.mhtml` saves of their actual GoFundMe pages: `c001`
  (formerly Maren, sample) → Jaye's "Help Jaye Get Through September
  and Rebuild" ($120 of $2,400, 2 donors, pinned as the homepage hero);
  `c006` (formerly Alex, sample) → gaynor/Midnight's "Midnight's
  Operation" (£40 of £1,300, 3 donors). Synced all three dataset copies
  (`campaigns.json`, `board-data.js`, `moderator-picker.html`'s two
  copies) using precise string anchors and verified by counting IDs in
  each, per the v33 lesson — no repeat of that truncation bug.
- **Confirmed feasible and used**: extracting a campaign's real photo
  directly from an uploaded `.mhtml` save of its page — the image
  referenced by the page's own `og:image` tag is embedded in the file
  and extractable, not just linked. Used this for both new campaigns'
  `imageUrl`. Documented in the moderator handbook as an alternative to
  manually copying an image URL.
- **Hero-selection logic changed**: any pinned campaign now wins the
  hero slot regardless of tier (previously: only pinned+seed-tier
  counted). Needed because Jaye's campaign already has 2 donors
  (First Five tier), and the explicit ask was to feature her on the
  homepage regardless — pinning is meant to be a stronger signal than
  the automatic tier preference, and the old logic didn't honor that
  for non-zero-donation campaigns. Unpinned `c005` (Diego, leftover
  sample data) so Jaye is unambiguously the sole hero rather than
  rotating between the two.
- Added a masthead image (`standin-image.jpg`, small/centered) to
  `index.html`, above the intro text.
- Rewrote the homepage intro copy per exact provided text, split into
  paragraphs (was one run-on block). **Restored the "not a charity...
  never touches anyone's donations" line as its own third paragraph**
  — it was present in the original text but absent from the exact
  replacement text given; flagged rather than silently dropped, since
  it's a load-bearing trust/disclaimer line used elsewhere too.
- Updated `board.html`'s TLC section paragraph to the exact provided
  text (softer tone, explicitly framing current rules as provisional).
  Minor fixes applied: "help system boost" → "help signal boost" (typo,
  consistent with the same phrase already used on the homepage), and
  the literal `<3` HTML-escaped to `&lt;3` so it renders as text rather
  than being parsed as a stray tag.
- Tested end-to-end: confirmed Jaye renders as hero with her real photo,
  Midnight's Operation appears correctly in the TLC section, and the
  "donate to today's featured campaign" link correctly follows Jaye.

**Why:** First real content replacing placeholders, plus a genuine
logic gap the real data surfaced — the tier system's seed-only hero
preference didn't actually support "feature this specific real person,"
which is precisely what pinning is supposed to enable.

---

## 2026-09-06 — v38: Outreach template excerpted to its own file

**Changed:**
- Created `INTERNAL_outreach-template.md` — a standalone excerpt of the
  "Notifying featured campaign owners" section, word-for-word from
  `INTERNAL_moderator-handbook.md`, which stays unchanged and remains
  the source of truth if the two ever need reconciling later.

**Why:** Direct request for quick standalone access to the template
without having to locate it inside the fuller handbook each time.

---

## 2026-09-06 — v37: Standard three-zip delivery, first blog post published, byline/date fields

**Changed:**
- Confirmed and documented: `private-notifier-repo.zip` ships alongside
  `live-site-files.zip` and `internal-docs-DO-NOT-COMMIT.zip` as a
  standing three-zip delivery from now on, not just when the notifier
  itself changes. Added to `INTERNAL_project-assistant-prompt.md` so
  this doesn't need re-establishing in a future session.
- Simplified the setup guide's Part 2: since the private notifier's
  `CAMPAIGNS_URL` already ships with the real confirmed URL baked in,
  the step that used to say "edit this placeholder" is now "nothing to
  edit, skip to secrets."
- Added Byline (default "Volunteer Team," editable per author) and Date
  (auto-fills to today, editable) fields to `blog-composer.html`,
  rendering as a dateline under the post title in generated output.
- **Published the first real post**: `why-boost-board-exists.html`,
  adapting `about.html`'s three-part origin story into blog voice,
  byline "Volunteer Team," dated 2026-09-07. Added to `blog.html`'s
  `posts` array — the blog is no longer empty.
- Tested end-to-end: composer's byline/date fields render correctly in
  generated HTML, and the real published post displays correctly on
  both its own page (nav, byline) and the blog index (title, link,
  date).

**Why:** Direct requests — always-ship-together delivery convention,
removing a setup step that's already been done, and getting the blog
past its placeholder-empty state with real, dated, attributed content
rather than leaving it as an unused feature.

---

## 2026-09-06 — v36: Real URL locked in, SEO/AEO/OG meta tags, WYSIWYG blog, Claude-assisted intake formalized

**Changed:**
- Real live URL confirmed and updated everywhere it was a placeholder:
  `https://jiandamonique.github.io/boostboard/` — README, the private
  notifier's `CAMPAIGNS_URL`, `overlay-generator.html`'s
  `BOOST_BOARD_BASE`, and every internal doc reference.
- Added a `.gitignore`/`.github` upload troubleshooting note (dotfiles
  are hidden by OS file pickers — use "Create new file" and type the
  full path instead of drag-and-drop).
- Formalized a third campaign-intake path: pasting raw information
  directly into a Claude conversation for Claude to structure and add
  to `campaigns.json` — now the active method being used to replace
  placeholder sample data with real campaigns.
- Added SEO/AEO/social-sharing meta tags to every public page except
  `embed-widget.html` (marked `noindex` instead, since it's iframe-only):
  meta description, canonical link, full Open Graph set, Twitter Card
  tags. `og:image`/`twitter:image` point to the lotus/hand artwork
  (`standin-image.jpg`) as an absolute URL, since social crawlers don't
  run JavaScript and can't pick up anything injected by `nav.js`.
  `index.html` also got a JSON-LD `WebSite` block for AEO.
- Built a WYSIWYG blog: `blog-composer.html` (a `contenteditable`
  editor using `document.execCommand()`, no external rich-text library)
  generates a ready-to-upload post file with matching SEO/OG tags and
  the shared nav/footer/widget includes already wired in; `blog.html`
  lists posts from a plain array, empty by default with an honest
  "Nothing posted yet" message. Composer is `noindex` and not in the
  main nav — a tool, not a page visitors should land on.
- Tested end-to-end: JSON-LD validity, meta tag correctness and page
  functionality after injection, and the composer's title→filename
  slug generation plus full HTML generation with a real formatted post.

**Why:** Batch of concrete production-readiness asks — locking in the
real URL everywhere it mattered, making the site properly shareable and
discoverable, and giving a genuinely code-free way to publish written
content without reintroducing a backend/CMS dependency.

---

## 2026-09-06 — v35: Confirmed real public repo name (boostboard)

**Changed:**
- Locked in the actual public repo name, `boostboard`, across the
  internal setup guide, the private notifier's `CAMPAIGNS_URL`
  placeholder, and `overlay-generator.html`'s `BOOST_BOARD_BASE`
  placeholder. Only the GitHub username remains a placeholder in each.
- Walked through the actual GitHub "Create a new repository" form
  field-by-field: Public visibility, no auto-added README/.gitignore/
  license (all three would conflict with or duplicate files already in
  `live-site-files.zip`, or contradict the earlier no-license decision).

**Why:** Reduces the remaining setup to "fill in your username" instead
of "figure out the whole URL pattern" — one fewer thing to get wrong
during actual deployment.

---

## 2026-09-06 — v34: ELI5 GitHub guide, non-scam-shaped outreach, Success Stories split from General Archive, roadmap pages

**Changed:**
- Wrote `INTERNAL_github-setup-guide.md` — full ELI5, click-by-click
  instructions for both the public site repo and the separate private
  notifier repo, plus exactly where to swap out dummy content and wire
  in real GoFundMe links. Also delivered in full in the chat body per
  request.
- Rewrote the good-faith outreach template with an explicit rationale:
  the original wording risked resembling a real scam pattern ("you've
  won something, email us to claim it" → upsell). New wording states
  plainly that the feature already happened or is about to, with no
  action required either way — two variants for "already live" vs.
  "sourced, about to be added."
- **Split Success Stories from the General Archive**, which were
  previously the same auto-generated list. `archive.html` (now titled
  "General Archive") stays fully automatic and informational — every
  graduated campaign, no curation. New `success-stories.html` is
  curated — written by the team or shared by a campaign owner, richer
  narrative than a database record. Empty by design right now, with a
  warm, specific empty-state message ("We hope that sometime soon we'll
  have some to share here") rather than generic placeholder text.
- Built `roadmap.html` (public, deliberately vague — current focus
  named as functionality and outreach, bigger direction stated as
  still-undecided rather than glossed over) and
  `INTERNAL_roadmap.md` (the honest, detailed version).
- `nav.js` updated: Success Stories now points to the new curated page,
  General Archive and Roadmap added as their own entries (11 pages
  total). Verified via headless execution across all three new/changed
  pages — nav, footer, and random-widget all correct, active-state
  highlighting correct on each.

**Why:** Direct requests across several related threads: onboarding
instructions simple enough for zero GitHub experience, an outreach
message that doesn't accidentally mirror a scam template, and a content
model that distinguishes "here's a database record" from "here's a
story someone actually wrote," each handled with the honesty the rest
of this project has been built around.

---

## 2026-09-06 — v33: Fallback eligibility (low percent-of-goal / low engagement)

**Changed:**
- Added `amountRaised`, `goalAmount` (optional, self-reported numbers)
  and `lowEngagementFlag` (optional, manual-judgment bool, never
  computed) to the campaign schema.
- `board-data.js`: new `percentOfGoal()`, `qualifiesAsFallback()`, and
  `fallbackLabel()` functions. `computeToday()`'s eligible pool now
  includes graduated (10+ donor) campaigns that qualify via low
  percent-of-goal (<10%, a named constant) or the manual low-engagement
  flag — they land in the TLC section only, never Zero Donations, with
  a transparent label instead of a blank or misleading tier badge.
- `archive.html`'s Success Stories filter updated to exclude fallback-
  qualifying campaigns — 12 donors on 2% of a large goal isn't a real
  success yet, even though it's technically past the graduation
  threshold.
- Added a demonstration campaign (`c008`, Rosa's home repair: 12
  donors, $300 of $20,000) to `campaigns.json` and synced it into both
  `board-data.js` and moderator-picker.html's two separate inline
  dataset copies. **Caught and fixed a real bug in the process**: a
  regex-based sync of the picker's second inline array (inside the
  "Load sample data" button handler) silently truncated to the wrong
  closing bracket, dropping the new campaign entirely from that copy.
  Fixed with precise string-anchored replacement instead, verified by
  counting IDs in both regions before considering it done.
- Added the two new fields to the moderator picker's add-form UI
  (amount raised, goal amount, a low-engagement checkbox), wired into
  the "Add to list" handler and the form's reset-on-open logic.
- Added public-facing transparency copy to `board.html`'s TLC section
  explaining the fallback pathway in plain terms.
- Tested end-to-end: the demonstration campaign correctly appears in
  the TLC section labeled "2% of goal reached," is correctly excluded
  from Success Stories, and the picker's add-campaign flow was verified
  by clicking through it in a headless browser (table row count
  before/after, not just internal state).

**Why:** Direct request to expand eligibility beyond pure donor-count
tiers for cases the current model misses. The mid-build bug (silent
truncation from an imprecise regex) is a useful reminder to verify
multi-location data syncs by content, not just "the syntax check
passed" — a truncated array is still syntactically valid JavaScript.

---

## 2026-09-06 — v32: Native SMTP (no third-party account), two-repo privacy split, GFM indexing note, Google Form workflow

**Changed:**
- **Rebuilt the notification pipeline around native SMTP** (nodemailer)
  through an email account already owned, replacing the Resend-based
  plan, per explicit preference to avoid depending on another account/
  third party.
- **Caught and fixed a real privacy issue before it shipped**: the
  subscriber list (`subscribers.json`, real email addresses) can't live
  in the same repo as the public site, since GitHub Pages normally
  requires a public repo and that would expose every subscriber's
  email. Split into two repos: the public one keeps `generate-rss.js`
  unchanged (no PII); a new `private-notifier-repo/` bundle holds
  `notify-subscribers.js`, `subscribers.json`, and its own workflow,
  fetching the public repo's `campaigns.json` over the network (no repo
  access needed) rather than checking it out directly.
- Tested the new script against a mock server standing in for the
  public repo's raw URL — fetch succeeds, then correctly proceeds to
  fail loudly on missing SMTP secrets, matching the same fail-loud
  design as before.
- Added a paraphrased (not reproduced) explanation of why automated
  zero-dollar campaign discovery doesn't really work — platforms
  deliberately exclude unpromoted/new campaigns from their own search
  to prevent spam — to the moderator handbook's sourcing section.
  Deliberately did NOT carry over specific example campaign URLs from
  the source material, since those can't be verified or vetted as
  appropriate to list.
- Added the same "why a computer can't just find these" explanation to
  `about.html`, extending the existing origin-story narrative with a
  concrete technical illustration of "algorithms count people out."
- Wrote out the full Google Form intake setup as concrete, actionable
  steps (exact question wording matching the parser's `FIELD_KEYS`,
  form settings, response-to-picker workflow) plus a report-form
  variant with the reason field the report-handling split requires.
- Updated pre-launch checklist and data retention doc for the two-repo
  architecture and subscriber-specific retention/unsubscribe handling.

**Why:** Direct preference for native infrastructure over a third-party
account, and a genuine privacy risk (subscriber PII in a public repo)
worth catching before anyone actually used this, not after.

---

## 2026-09-06 — v31: Manual sourcing guide, dual-purpose report button, queue-delay transparency

**Changed:**
- Added a "Sourcing campaigns manually" section to the moderator
  handbook — paraphrased general techniques (site-restricted search,
  browsing a platform's newest listings, categories with historically
  lower organic reach) generalized to any platform, not just GoFundMe.
  Verified GoFundMe's own current search/filter limitations before
  writing this, rather than assuming a pasted list was still accurate.
  Flagged that sourced campaigns need the good-faith notification sent
  *promptly* rather than as an afterthought, since — unlike a
  self-submission — the person has no idea Boost Board exists until
  told.
- Report link relabeled "Report / Update" with an explanatory title
  attribute, and the demo alert text updated to describe both purposes:
  reporting a concern, or just flagging that a campaign already has
  donations so the count can be updated.
- Documented (backend doc + pre-launch checklist) that these are two
  genuinely different categories needing different handling — a
  concern should still trigger instant-hide, but "already has
  donations" should NOT hide a perfectly good campaign. The real
  report-intake form (not yet built) needs a reason field to route
  these differently; until then this is a documented requirement, not
  yet enforced in code.
- Added a public transparency note to `board.html`: campaigns are
  reviewed by hand before appearing, which takes time, so a featured
  campaign may already have picked up a donation elsewhere by the time
  it's shown — framed as a good sign, not an error, with a pointer to
  the Report/Update link.

**Why:** Direct request to support manual campaign discovery alongside
self-submission, plus the honest acknowledgment that queuing delays
mean "featured" doesn't always mean "still at zero" — better to say so
plainly than let a visitor feel misled.

---

## 2026-09-06 — v30: Left-hand sidebar navigation

**Changed:**
- Rewrote `nav.js`'s layout: fixed 220px left-hand sidebar on screens
  ≥700px wide (body gets `padding-left` injected via the same stylesheet
  so content shifts right instead of being covered), collapsing to the
  original horizontal top bar below that breakpoint. Same link list,
  same active-page logic — only the CSS changed, no other file needed
  edits.
- Verified via headless execution on two pages (`index.html`,
  `board.html`): nav still renders all 9 links, active-state
  highlighting still works, footer and random-widget scripts (which
  only depend on `nav.js`'s exposed link list, not its layout)
  unaffected.

**Why:** Direct request for a left-hand panel layout. Kept the
narrow-screen behavior as the original horizontal bar rather than
forcing a sidebar everywhere, since a fixed 220px panel would consume
most of a phone-width viewport.

---

## 2026-09-06 — v29: Resend chosen for RSS-to-email, stale-reference audit, docs sync

**Changed:**
- Verified current Resend free tier (3,000 emails/month, 100/day,
  genuine audience/broadcast support) fits the multi-subscriber need —
  distinct from the personal-digest tools (rss-email-digest, rss2email,
  etc.) researched, which solve a different problem (one person, their
  own inbox) than Boost Board needs (one feed, many external
  subscribers).
- Built and tested `notify-subscribers.js` — recomputes the hero,
  compares against `last-notified.json` to prevent duplicate sends if
  the same campaign stays featured across days, calls Resend's
  broadcast API only on an actual change. Verified both the
  first-run-attempts-send and duplicate-correctly-skipped paths.
  Wired into `.github/workflows/daily-rss.yml`.
- Ran a stale-reference audit across every public and internal file per
  direct request ("let's make sure we have everything to date"). Found
  and fixed: `credits.html` still said "today's Booster" and referenced
  "the homepage" for the donate link, both stale since the v27/v28
  restructure and naming changes — now correctly says "today's featured
  campaign" and "The Board page." Also found and rewrote the internal
  ops doc's entire tech-stack section, which still described the
  deleted `spotlight-widget-demo.html` as if current — now accurately
  documents `index.html`/`board.html`/`board-data.js` and every new
  script added since.
- Updated the pre-launch checklist with concrete next steps: Resend
  account/domain/audience setup, and the still-unbuilt subscriber
  signup-to-audience bridge.

**Why:** Direct request to keep user-facing and internal documentation
synchronized — this pass caught real drift (a leaked internal nickname
in public copy, a stale file reference in internal docs) that would
have been confusing to a future reader of either.

---

## 2026-09-06 — v28: About page, Success Stories archive, sitewide random widget, embeddable widget

**Changed:**
- Built `about.html` explaining the three origins: algorithmic burial of
  zero-donation campaigns, predatory pay-to-play marketing services
  targeting fundraisers, and the This American Life "Best Gig Ever"
  story (Ep. 286/588) reframed as the same generous impulse done
  honestly instead of as a con. Verified the real story's facts via
  search before writing, including a genuine happy-ending detail (the
  band later performed at Improv Everywhere's own anniversary show) —
  not invented, found in the sourcing.
- Recommended and built `archive.html` ("Success Stories") — lists
  graduated (10+ donor) campaigns, using data the site already tracks.
- Built `random-campaign-widget.js` — small, centered, genuinely random
  (not date-seeded) campaign widget at the bottom of every public page,
  below the footer sitemap. Verified via full sweep across all 9 public
  pages.
- Built `embed-widget.html` — a minimal iframe-only page external sites
  can embed, supporting `?mode=hero` or `?mode=random`. Added a
  copy-to-clipboard embed-code generator to `overlay-generator.html`.
  **Placeholder domain in that generator needs updating before
  publishing** (see pre-launch checklist).
- `nav.js` updated with both new pages; confirmed all 9 pages still
  render nav, footer, and widget correctly after the change.

**Why:** Direct requests — origin story, sitewide incidental exposure,
and third-party embeddability all extend Boost Board's reach beyond its
own pages without adding any new moderation surface (embeds only ever
show already-approved campaigns).

---

## 2026-09-06 — v27: Landing page + Board split, tier explanations, RSS automation, reframed newsletter

**Changed:**
- **Major restructure**: split the single combined page into `index.html`
  (simple landing page — brief explanation + today's hero, now the
  biggest thing on the page since nothing competes with it) and
  `board.html` ("The Board" — the full Zero Donations + TLC sections,
  no hero repeated). Extracted shared logic into `board-data.js`
  (`computeToday()`, `tierOf()`, `selectSection()`) so both pages use
  one source of truth instead of duplicating the dataset. Deleted the
  now-superseded `spotlight-widget-demo.html`.
- Added tier explanations directly on `board.html`, next to the tiered
  content itself (discovery-model approach, not a separate FAQ page) —
  explains Seed/First Five/First Ten and the graduation concept right
  where a visitor is already looking at those labels on real cards.
- Updated `nav.js` with the new page list (`index.html` first, `board.
  html` second) — verified via headless execution that active-page
  highlighting works correctly on both.
- Built `generate-rss.js` + `.github/workflows/daily-rss.yml` — a
  scheduled GitHub Action that regenerates `rss.xml` daily from
  `campaigns.json`, mirroring the same hero-selection logic as the live
  site. Explicitly reasoned through why this one IS safe to automate
  unlike moderation: it only recomputes an already-approved selection
  deterministically, makes no new trust decision.
- Checked current info before assuming otherwise: **Buttondown's RSS-
  to-email automation is a paid-tier feature as of mid-2026**, not free.
  Documented two real paths forward (Buttondown's direct-API-send
  workaround, or wiring the GitHub Action to call a chosen provider's
  API directly) — deliberately left unbuilt pending a provider decision,
  since free-tier terms change and shouldn't be assumed.
- Added a "Get an email when someone needs a first donation" section to
  `credits.html` — explicitly reframed away from newsletter conventions
  (no roundups, no updates, one email per zero-donation feature only),
  named plainly rather than branded.

**Why:** Directly fixes the "hero should be bigger than what's beneath
it" problem structurally rather than with a CSS trick — removing the
competing content is what actually makes it bigger. Tier explanations
placed contextually match the explicitly requested "discovery site"
model over an upfront explainer page. RSS reasoning specifically
distinguishes safe-to-automate recomputation from the moderation
decisions that must stay manual — worth being precise about that line
rather than treating "automation" as one undifferentiated category.

---

## 2026-09-06 — v26: Brand-name-runs-the-campaign decision, self-pin hard rule

**Changed:**
- Confirmed: the brand name is a DBA under the same sole
  proprietorship as the personal name — same tax ID, same liability,
  not a separate entity. Prior campaigns under both names, no issues.
- Decision: the Boost Board GFM campaign runs under the **brand name**,
  not the personal name — purely for donor-facing clarity between "help
  me personally" and "help fund this app," since the tax/legal reality
  is identical either way and this doesn't solve a legal problem, just
  a perception one.
- Added a hard rule, distinct from the naming question: **never pin a
  personal or brand-name campaign belonging to the moderator onto Boost
  Board's own board.** That's the actual self-dealing risk — the person
  holding pin power benefiting their own listed campaign — and it's
  flagged as a bright line specifically because it would be tempting to
  bend if things got financially tight personally.

**Why:** Direct question about running a concurrent personal GFM
campaign alongside Boost Board's — resolved the identity/branding
question and surfaced the more important adjacent risk (self-pinning)
that the naming decision alone wouldn't have caught.

---

## 2026-09-06 — v25: Actual filename renamed to match page title

**Changed:**
- Renamed the file itself: `while-you-wait.html` → `helpful-fundraising-
  ideas.html`. Earlier renames (v21, v23) only changed the `<title>` tag
  and on-page header — the underlying filename still said "while-you-
  wait," which is what file-card/artifact previews actually display.
- Updated every reference: `nav.js`'s link list and the homepage's
  inline link text in `spotlight-widget-demo.html`. `footer.js` needed
  no change, since it reads the same list from `nav.js` automatically.
- Verified via headless execution: correct title, correct active-nav
  highlighting, and all 6 footer links intact on the renamed file.

**Why:** "The page name" meant the actual filename, not just the
in-page copy — worth remembering for future renames that the filename
itself is often what's visibly shown, separate from `<title>` or
on-page headers.

---

## 2026-09-06 — v24: Anonymous-donor note added to Helpful Fundraising Ideas

**Changed:**
- Added a section to `while-you-wait.html`: some donors choose to stay
  anonymous, and that should be respected (no guessing/revealing who
  they are). Suggests using a platform's automatic thank-you message
  feature, since it reaches anonymous givers the same way it reaches
  everyone else without needing to know their identity, plus a general
  public thank-you line that includes anonymous givers without singling
  anyone out.

**Why:** The existing "say thank you publicly" tip only worked for named
donors — this fills a real gap for anonymous ones without undoing the
non-shaming, low-pressure tone already established on the page.

---

## 2026-09-06 — v23: Rejected mismatched content, added two new pages, shared footer sitemap

**Changed:**
- Declined to import a pasted product/equity-crowdfunding best-practices
  list wholesale — flagged specific lines ("won or lost before launch,"
  "30% in 48 hours," months of pre-launch audience-building) as directly
  undermining the non-shaming principle from v17, since Boost Board's
  audience is mostly personal-need donation fundraisers, not product
  launches. Person agreed the content was pasted from an unrelated
  article. Folded in only the one genuinely transferable idea (a short
  update during a wait, reworded without the "hostile" framing from the
  original) rather than the full list.
- Renamed "Helpful Ideas" → **"Helpful Fundraising Ideas"** (title,
  header, nav label).
- Added a growable "Volunteer & team campaigns" section to
  `credits.html` — a plain JS array (`volunteerCampaigns`), no limit on
  entries, each rendering with a "please consider donating here too"
  CTA. Currently empty with a clean empty-state message.
- Created two new public pages: **`fundraising-platforms.html`** (a
  neutral reference list of common platforms — GFM, Indiegogo/
  Kickstarter, Venmo/CashApp/PayPal.me, Ko-fi/GiveSendGo/Fundly — with
  no endorsement framing) and **`emergency-help.html`** (211, Mutual Aid
  Hub, and community-specific-org guidance for needs faster than a daily
  rotation can serve — verified 211 and Mutual Aid Hub are still active
  via search before publishing either).
- Built `footer.js` — an old-school, plain-underlined-link sitemap
  footer appended to every public page, reusing the same page list
  `nav.js` already builds (via `window.BOOST_BOARD_PAGES`) so there's
  one list to maintain, not two. `nav.js` updated to include both new
  pages.
- Verified via headless execution: nav and footer both render with all
  6 pages linked on the new fundraising-platforms page; credits page's
  empty volunteer-campaigns state renders correctly.

**Why:** Protects the established non-shaming tone against
well-intentioned but mismatched pasted content; the two new pages
extend Boost Board from "here's today's board" toward "here's where to
look if this specific tool isn't fast enough for you," which is a more
honest, complete answer to "we can't always help in time."

---

## 2026-09-06 — v22: Consolidated pre-launch checklist

**Changed:**
- Added a "Pre-launch checklist" section to `INTERNAL_operations-howto.md`
  consolidating every outstanding action item flagged across this whole
  build into one checkable list: the `index.html` rename, `nav.js`
  maintenance note, all remaining `href="#"` placeholders (credits give-
  button, report link), unbuilt intake/report forms, the two human-
  professional review items (legal, accessibility), and remaining
  content gaps (credits names, First Encourager naming, GFM goal amount).

**Why:** Direct request — deployment instructions mentioned only in
chat aren't the same as instructions written where a future session
will actually find them. This turns scattered mentions into one
actionable checklist instead of something that has to be remembered or
reconstructed later.

---

## 2026-09-06 — v21: "Helpful Ideas" rename, closing disclaimer rewrite, First Encourager leaning

**Changed:**
- Renamed the public-facing "While You Wait" page to "Helpful Ideas" —
  updated the `<title>`, the on-page eyebrow label, and the `nav.js`
  navigation label. Filename/URL (`while-you-wait.html`) deliberately
  left unchanged to avoid breaking the existing link from the homepage.
- Rewrote the page's closing disclaimer per exact provided wording
  (typos corrected: "si" → "is," "additonal" → "additional," sentence
  capitalization): now reads "This project is run by volunteers, with
  varying availability and capacity. We will do our best to review your
  campaigns. In the meantime, we hope this information is helpful.
  Please also refer to your donation platforms' FAQs for additional
  support." Replaces the earlier "we'll get to your campaign" wording.
- Updated the homepage's reference link text from "read this guide" to
  "read some helpful ideas" for consistency with the rename.
- "First donor" naming: leaning **First Encourager** over "Early
  Encourager" — ties more precisely into the existing First Five/First
  Ten naming pattern. Not fully locked in.
- Confirmed alignment: "Support the app" (homepage) already points to
  `credits.html`; `credits.html`'s own give-button is the one remaining
  placeholder (`href="#"`) that becomes the real GFM link once it
  exists — both stay pointed at the same single destination by design.

**Why:** Direct wording/naming requests; the "Helpful Ideas" rename
better matches the non-shaming framing established in v17 than "While
You Wait," which read slightly more transactional/impatient.

---

## 2026-09-06 — v20: Funding worksheet priced with real figures

**Changed:**
- Replaced "TBD" placeholders in the GFM funding-goal worksheet with
  concrete recommended figures: $20/yr hosting, $150/month moderator
  stipend, $150 one-time dev buffer, $350 accessibility audit, $250
  legal consult, 12% contingency.
- Framed the pricing logic explicitly: AI does repeatable/mechanical
  work for free (this entire build), humans get paid specifically for
  judgment and professional accountability that shouldn't be automated
  away — moderator review, a real accessibility audit, and a lawyer's
  eyes on the privacy policy are the three lines protected by that
  principle even though AI assists all three.
- Added two concrete runway scenarios: lean 3-month (~$1,350,
  recommended) vs. comfortable 6-month (~$1,915), framed as "first N
  months of operation" rather than a lump sum, since GFM has no
  duration cap unlike Indiegogo.

**Why:** Turns an open question into an actual, defensible number the
campaign copy can use, while keeping the reasoning (not just the
figures) documented so it doesn't need re-deriving later.

---

## 2026-09-06 — v19: Shared navigation, confirmed multi-page architecture over SPA

**Changed:**
- Confirmed and documented: GitHub Pages hosts any number of static
  pages with no special configuration — the "should this be several
  pages" question was already answered by the existing architecture.
  Explicit decision against a React/tabs SPA: stays vanilla multi-page,
  consistent with the zero-dependency philosophy carried over from the
  original artist-directory repo.
- Built `nav.js` — a single shared script injecting a consistent nav bar
  (Boost Board / While You Wait / Campaign Tools / Credits & Support)
  into every public page, with active-page highlighting based on the
  current filename. Included via one `<script defer>` tag per page
  rather than duplicating nav markup by hand into four files.
  `moderator-picker.html` deliberately excluded — internal tool, not
  part of the public navigation flow.
- Flagged and documented the homepage-naming requirement: GitHub Pages
  serves whatever's named `index.html` at the repo root, and
  `spotlight-widget-demo.html` still carries its original demo-file
  name — needs renaming (or Pages settings pointed at it) before actual
  deployment.

**Why:** Answers a real hosting question with the correct technical
constraint (GH Pages doesn't limit page count) rather than reaching for
unnecessary framework complexity, while fixing the actual navigation gap
that existed regardless of which architecture was chosen.

---

## 2026-09-06 — v18: Platform-agnostic campaign tools page, unattended-operation spec documented

**Changed:**
- Built `overlay-generator.html` — a platform-agnostic equivalent of
  GoFundMe's own "Live fundraising tools" overlays: enter a campaign
  name, link, amount raised, and goal; get a downloadable PNG progress
  graphic and a QR code linking to the fundraiser. Works for any
  platform, including a bare Venmo/CashApp link, which GFM's own tool
  can't serve. Self-reported and manually refreshed, same honesty
  constraint as everything else — no live API exists for any platform.
  Progress graphic is built as raw SVG specifically so it rasterizes to
  PNG reliably via canvas; QR code comes from a free third-party service
  (api.qrserver.com) rather than a bundled encoder library.
- Added an explicit "Autonomous / unattended operation" section to the
  ops doc, capturing (as internal reference, not just a chat answer) that
  the board correctly keeps rotating with zero moderator activity for 7+
  days — rotation is client-side and date-seeded, pins persist, reports
  stay correctly hidden — and exactly what doesn't happen without a
  human (new-submission approval, report resolution).

**Why:** Extends the "self-reported, ToS-friendly, no scraping" pattern
already established for images and donation counts into a genuinely
useful self-service tool, rather than leaving platform-agnostic
campaigns with no equivalent to what GFM offers its own organizers.
Documenting the unattended-operation behavior in the actual ops doc
(not just answered once in conversation) means it doesn't have to be
re-derived or re-explained later.

---

## 2026-09-06 — v17: Funding goal worksheet, no parallel payment channel, non-shaming best-practices rewrite

**Changed:**
- Added a line-item funding-goal worksheet to the GFM plan doc (hosting,
  moderator time, dev time, accessibility review, legal consult,
  contingency) with a bias toward a lower, defensible ask over a round
  aspirational number.
- Decided against a parallel Venmo/PayPal channel for app funding —
  GFM only, to avoid fragmenting the progress-bar social proof and
  reconciliation work. Documented the reasoning in the plan doc so it
  doesn't need re-litigating later.
- Continued "first donor" naming ideation (First Encourager, First
  Believer, The First Yes, First Hand, Day One, The Opener) — still
  open, leaning warm-but-plain rather than game-y.
- Rewrote `while-you-wait.html` with an explicit non-shaming framing
  statement up front: the guide exists precisely because doing
  everything "right" doesn't guarantee reach, and following (or not
  following) any of it isn't a reflection on the person. Added a new
  section on it being okay to ask someone close to give first, framed
  as a low-pressure option rather than a required tactic — folds in the
  general "prime the pump" crowdfunding idea without implying the
  person didn't try hard enough.

**Why:** Direct request to avoid the guide reading as "here's what you
did wrong" — the whole premise of Boost Board is that good campaigns get
buried for reasons unrelated to effort, so the guide needed to say that
explicitly rather than implicitly undercut it.

---

## 2026-09-06 — v16: Dedicated Zero Donations section, pin cap, live-fundraising-tools reference

**Changed:**
- Restructured the public page into three sections instead of one hero +
  one grid: **Hero** (1, prefers zero-donation) → **More campaigns with
  zero donations** (up to 15) → **Campaigns already building momentum**
  (up to 10, first_five/first_ten tiers only). Refactored the selection
  logic into a shared `selectSection(pool, size)` function used by all
  three, replacing the old single `buildBoard()`.
- Added `PIN_CAP = 5` (recommended, not a hard technical constraint) —
  enforced in the picker's star-toggle and random-pick handlers, blocking
  a 6th pin with an explanatory alert. The manual override-by-ID field
  stays exempt, since it's the documented emergency bypass, not routine
  use.
- Confirmed and documented: with zero moderator activity for an extended
  period, the board keeps rotating correctly on its own (client-side,
  date-seeded, no server dependency) — pinned entries stay pinned
  indefinitely, reported entries stay correctly hidden. What doesn't
  happen without a human: new submissions don't get approved, and
  reports don't get resolved (though the fail-closed hide is itself
  still correct behavior).
- Reviewed GoFundMe's own "Live fundraising tools" (beta) organizer
  dashboard (shareable link + streaming overlays: live progress bar,
  donation alerts, QR code) as a reference. Not built into anything yet
  — noted as a possible future *optional* intake field (a submitter
  voluntarily pasting their own overlay link), since that's meaningfully
  different from scraping: it's data the campaign owner chooses to share.

**Why:** Reframes the zero-donation tier from "one example shown" to
"here's the actual scale of the problem, pick one" — a stronger version
of the original zero-donation-visibility pitch. Pin cap answers a
previously-flagged open question with a concrete, adjustable number.

---

## 2026-09-06 — v15: Cute branding removed from public copy, report mechanic kept backend-only, onboarding prompt created

**Changed:**
- Public hero eyebrow changed from "Inbox Zero" to plain "Today's
  featured campaign" — the "Inbox Zero" name stays as internal-only
  shorthand for the zero-donation hero-selection mechanism, never shown
  to users. "Zero to Hero" naming rejected as too cutesy; "Booster" as a
  nickname for a featured campaign dropped entirely in favor of plain
  "today's featured campaign" wording everywhere (support block, hero).
- Added a naming-ideation log to the backend doc (Clean Slate, The Zero
  Spot, Ground Floor, First Look, etc.) to keep workshopping without
  touching any live copy until something sticks.
- Explicitly documented — in the moderator handbook and backend doc —
  that the "a report instantly hides a campaign, even a pinned one" rule
  must never be explained in public-facing copy, since publishing the
  exact mechanic would hand bad-faith reporters a precise way to
  suppress a legitimate campaign. Added guidance on watching for
  malicious-reporting patterns and treating report review as genuinely
  time-sensitive given the instant-hide effect.
- Created `INTERNAL_project-assistant-prompt.md` — a standalone
  onboarding prompt capturing the project's purpose, the internal/public
  file-split rule, every standing decision made so far, and working-style
  norms, meant to be pasted at the start of a future session so nothing
  has to be re-explained from scratch.

**Why:** Consolidating "no cute branding" as a firm, general rule rather
than a one-off note, protecting a real security-relevant mechanic from
public disclosure, and — per direct request — creating a reusable prompt
so this collaborative process doesn't have to be reconstructed from
memory every time.

---

## 2026-09-06 — v14: GFM plan, payment-agnostic links, pin reasons, WYSIWYG preview, offline fallback parser, credits page

**Changed:**
- Marked `INTERNAL_indiegogo-campaign-plan.md` superseded, created
  `INTERNAL_gofundme-campaign-plan.md` with the platform-switch reasoning,
  an explicit "why this isn't a fundraising pool" section for the ToS/
  optics concern, and draft campaign copy.
- `link` field documented (and already functionally supported) as
  payment-platform-agnostic — GoFundMe, Indiegogo, bare Venmo/CashApp/
  PayPal.me links all work the same way, supporting very low-structure
  submissions (e.g. a tweet with just a payment handle).
- Added `pinReason` field — optional, moderator-entered, shown publicly
  under "Editor's Pick" on both the grid card and the hero when set.
  Pinning itself stays fully manual, as it always has.
- Added a live WYSIWYG preview to the moderator picker's add-form,
  updating on every keystroke, so the card's public appearance is visible
  before adding it.
- Added `fuzzyParse()` — a free, offline, regex-based fallback parser for
  completely freeform text (recognizes bare payment-platform domains like
  `venmo.com/...` without needing `http://`). The "Smart parse" button now
  tries the AI path first and automatically falls back to this one if no
  API key is available, rather than just failing — no cost either way,
  and the form shows which method was used.
- Added extra screening-checklist guidance in the moderator handbook
  specifically for bare payment-handle submissions, which carry different
  scam risk than a platform-hosted fundraiser page.
- Created `credits.html` — a public page for tipping the app itself
  directly (distinct from donating to a featured campaign), plus a
  thanks/credits section.

**Why:** Several linked concerns resolved together: platform-switch
follow-through, addressing the self-referential-fundraising optics
concern head-on rather than hoping it doesn't come up, supporting much
lower-effort submissions (a tweet, not a full platform page) without
sacrificing screening rigor, making pinning transparent when used, and
making the AI-parse feature actually usable for a project with no API
budget rather than a nice-to-have that only works some of the time.

---

## 2026-09-06 — v13: Non-charity disclaimer, dual support ask, outreach template, AI smart-parse

**Changed:**
- Restored "don't wait on us alone" phrasing in the board's volunteer-run
  copy, merged with the existing guide link, per explicit direction that
  the public impression should be "runs on its own" even though intake
  and reporting are human-moderated throughout.
- Added a public disclaimer block: Boost Board is explicitly framed as
  "not a charity or nonprofit — it's an app," with two support options
  presented side by side: fund the app itself, or donate directly to
  today's "Booster" (placeholder nickname — final naming still open).
  The Booster-donation button dynamically links to whichever campaign is
  today's hero.
- Added a good-faith notification template to the moderator handbook for
  telling featured campaign owners they've been featured — explicit "no
  reply expected" framing, written so the same wording works whether a
  human sends it manually today or a script sends it automatically
  later.
- **Retention policy changed as a consequence**: submitter email can no
  longer be deleted right after the approve/decline decision, since
  notification happens at feature-time, which may be days or weeks
  later. Updated both `INTERNAL_data-retention.md` and the public
  privacy policy draft to reflect the longer window.
- Added AI-based "smart parse" to the moderator picker for fully
  freeform pasted text (not just labeled Question/Answer pairs), calling
  the Claude API directly from the browser. Documented clearly that this
  only functions while the tool is running as a Claude artifact — a
  plain downloaded HTML file has no API key and the feature fails
  gracefully back to the label-based parser or manual entry.

**Why:** Several distinct asks bundled into one working session: public
messaging clarity (not a nonprofit), a concrete way for visitors to
choose where their money goes, a human-to-human courtesy step that's
still automation-ready, and a more powerful intake option for submitters
who don't write in the form's expected shape.

---

## 2026-09-06 — v12: Homepage restructured around an "Inbox Zero" hero

**Changed:**
- Homepage is no longer a flat grid — it now leads with one large hero
  campaign ("Inbox Zero"), pulled preferentially from today's seed-tier
  (0-donation) pool, with marketing copy framing the empty donation
  count as proof the model works ("Do you see a donation here? Woo
  hoo!"). Falls back to a generic "Today's featured campaign" framing if
  no seed-tier campaign is on today's board.
- The remaining board (up to 9 more) renders below under "More campaigns
  that need some TLC," with a smooth-scroll link from the hero.
- Hero is drawn from the same daily board computation as the grid, not a
  separate pick, and is excluded from the grid so it isn't shown twice.
- Noted as a side effect: pinning a specific zero-donation campaign now
  functions as a way for a moderator to effectively choose tomorrow's
  Inbox Zero hero, since pinned + seed-tier is the top preference.

**Why:** Marketing reframe — instead of a zero-donation campaign reading
as "struggling," it becomes the proof point that the system catches
campaigns before an algorithm buries them. One prominent hero also gives
new visitors a clear first thing to look at instead of a full grid.

---

## 2026-09-06 — v11: Paste-and-parse intake in the moderator picker

**Changed:**
- Added an "Add a new campaign" section to `moderator-picker.html`: paste
  a submission's text (matching the intake form's question labels) and
  click "Parse pasted text" to auto-fill the name/link/communities/
  description/donation-count fields, or click "Or start blank" to skip
  straight to manual entry. Either path shows an editable preview before
  anything is added.
- Parser matches on labeled paragraphs (`Question` line, then answer
  text, separated by blank lines) — the same shape a Google Form
  response naturally comes out as. Unmatched fields just stay blank and
  editable rather than failing.
- Submitter email, if present in the pasted text, displays for the
  moderator's own reference only — never written into the new
  `campaigns.json` entry, consistent with the existing data-retention
  policy.
- Documented the required intake-form label wording in
  `INTERNAL_operations-howto.md` so the form and parser stay in sync.

**Why:** Hand-editing raw JSON per submission was tedious and error-prone
for routine intake. Paste-and-parse handles the common case fast while
leaving manual entry available for anything unusual.

---

## 2026-09-06 — v10: Placeholder shows full artwork, not a crop

**Changed:**
- Replaced the cropped `standin-image.jpg` (heart+hand only) with the
  full original artwork, including the lotus/ripple detail at the
  bottom.
- Changed `.card-image-fallback` from a fixed landscape height (130px)
  to an `aspect-ratio` matching the artwork's actual portrait
  proportions (700:819), so the whole image displays without cropping.
  Only the fallback/placeholder box changed — real campaign photos
  (`.card-image`) keep the original landscape treatment, since typical
  fundraiser cover photos are landscape.

**Why:** The earlier crop cut off the lotus/ripple detail to force a
landscape composition; keeping the full piece was worth a taller
placeholder card instead.

---

## 2026-09-06 — v9: "While you wait" guide added, linked from board copy

**Changed:**
- Created `while-you-wait.html` — an original, platform-agnostic guide
  (update your page, ask people directly, be specific, say thank you,
  try more than one place), written plain-language rather than linking
  to an external article.
- Updated the board's volunteer-run disclaimer copy to link to it.

**Why:** An earlier idea was to link out to a third-party fundraising
best-practices article; writing an original short page instead avoids
link rot, matches the site's plain-language accessibility standard, and
keeps the advice platform-agnostic (not GFM-specific) as originally
intended.

---

## 2026-09-06 — v8: Real placeholder artwork replaces built icon

**Changed:**
- Replaced the flat SVG hand/heart icon entirely with a user-provided
  watercolor illustration (`standin-image.jpg`), cropped to a landscape
  composition centered on the heart and hand, sized for the card slot.
- Switched the fallback from an inlined base64 data URI back to a real
  file reference (`./standin-image.jpg`) alongside the HTML/JSON files,
  since a hand-made image asset belongs with the other site files rather
  than bloating the widget's inline code.
- Removed `standin-image.svg` — superseded.

**Why:** The generated flat-icon version wasn't landing visually; a
hand-drawn piece communicates the project's tone better than an
icon-style placeholder could.

---

## 2026-09-06 — v7: Placeholder icon redesign, Indiegogo category confirmed

**Changed:**
- Replaced `standin-image.svg` with a flat, two-tone hand-offering-heart
  icon (matching the reference image provided), keeping the site's
  existing color tokens rather than the reference's original palette.
  Same wiring as before — shown whenever a card has no `imageUrl` or the
  image link breaks.
- Confirmed (not just proposed) the Indiegogo category decision:
  Community Projects → Human Rights or Wellness, over Tech & Innovation.

**Why:** First placeholder read as too abstract; a literal hand/heart
icon communicates "mutual aid" more directly to anyone seeing an
unfilled card. Category confirmation closes one of the open questions
from the v6 planning doc.

---

## 2026-09-06 — v6: Placeholder image asset, Indiegogo reward planning

**Changed:**
- Created `standin-image.svg` — an abstract, on-brand placeholder graphic
  (no depicted people, matches existing color tokens) used whenever a
  campaign has no `imageUrl` set or its image link breaks. Replaces the
  earlier plain letter-avatar fallback in `spotlight-widget-demo.html`.
- Started `INTERNAL_indiegogo-campaign-plan.md` — category decision
  (Community Projects over Tech & Innovation), sole-proprietor
  implications, draft reward tiers, and an explicit rule that no reward
  may ever buy influence over which campaigns get featured.

**Why:** Indiegogo requires reward-based tiers, not pure donations —
needed a reward structure that couldn't be read as pay-to-play against
the platform's own fairness design. Placeholder image was needed since
campaign images are manually sourced (no auto-fetch, per the v5 note on
CORS/scraping limits) and a blank/lettered box read as unfinished rather
than intentional.

---

## 2026-09-06 — v5: Images, privacy draft, licensing decision, doc split

**Changed:**
- Added `imageUrl` field to `campaigns.json` schema.
- Public board (`spotlight-widget-demo.html`) now renders a campaign
  image if present, falls back to a letter-avatar if missing or the
  image link breaks (`onerror` handler).
- Moderator picker gained an editable image-URL text field per row.
- Drafted `INTERNAL_privacy-policy-DRAFT.md` — written to eventually be
  public, deliberately held back from the live repo until ready to
  publish on purpose.
- Confirmed decision: no LICENSE file in the public repo. Default
  copyright (all rights reserved) preserves optionality for a possible
  future relaunch as a funded site/NPO/product.
- Public README's contact section now points to GitHub Issues instead of
  a placeholder contact method.
- Added a full tech-stack/code-walkthrough section to
  `INTERNAL_operations-howto.md` (every function in both HTML files,
  what it does, local-run vs. deploy instructions).

**Why:** Reinforces the split established at v4 — anything that explains
*how* this works (mechanics, code, design rationale) stays internal-only,
given the stated intent to possibly relaunch this as a full product
later. The public repo should read as "here's a working thing," not "here's
the recipe."

**Known limitation carried forward:** No automated way to pull a
campaign's image (or donation count) directly from its fundraiser page —
cross-origin browser restrictions plus scraping/ToS concerns rule that
out for a static, serverless site. Both remain manual, moderator-entered
fields by design, not an oversight.

---

## 2026-09-06 — v4: Ten-slot board, editorial pins, reports, doc split

**Changed:**
- Replaced the earlier "one campaign per tier" board with a single
  10-slot daily board. Fewer than 10 approved campaigns just means fewer
  slots filled that day.
- Added `pinned` field — editorial cherry-picks now get a guaranteed
  board slot ("Editor's Pick"), independent of tier or rotation order.
- Added `reported` field — automatically hides a campaign from the
  public board (pin status notwithstanding) until a moderator clears it.
- Rebuilt the automatic rotation as a deterministic, date-seeded queue
  (not true randomness) so every approved campaign gets a turn before
  any repeat — removes reliance on a scheduled job/cron entirely.
- Moderator picker gained: recency-guarded random pick (excludes anyone
  featured in the last 7 days), a manual override-by-ID field for
  urgent/glitch fixes, and pin/report toggle controls.
- Split documentation for the first time: public README stripped down to
  generic, non-technical content; created the internal-only archive
  (`internal-docs-DO-NOT-COMMIT.zip`) containing the moderator handbook
  and data-retention notes.
- Created two separate zip outputs going forward: `live-site-files.zip`
  (safe for GitHub) and `internal-docs-DO-NOT-COMMIT.zip` (offsite only),
  plus a `.gitignore` as a backstop against internal files ever landing
  in the public repo.

**Why:** Reflects the real intake model — a moderator manually reviews
every submission via an embedded form (not a GitHub Issue, which is too
high-friction for the target audience) before it's added to the shared
JSON. Automating *rotation* among already-approved entries removes daily
manual toil without automating the actual trust-and-safety judgment call,
which stays human.

---

## 2026-09-06 — v3: Moderator-driven selection replaces cron automation

**Changed:**
- Removed the originally-planned scheduled GitHub Action / cron job.
- Introduced `moderator-picker.html` — a standalone tool where a human
  loads pending submissions, gets a "pick one at random" assist per
  tier, and downloads the updated file to publish manually.
- Clarified the actual submission flow: contact form / email, not a
  GitHub Issue, with self-reported donation counts honored even if a
  donation trickles in before the moderator reviews it.

**Why:** Original design assumed donation-count changes could be
detected automatically; clarified that a human moderator reviews every
submission regardless (GFM's own scam detection doesn't catch everything
at volume), making full automation of the selection step both infeasible
and undesirable.

---

## 2026-09-06 — v2: Milestone tiers replace single boolean flag

**Changed:**
- Replaced the binary `needsBoost` flag with a `donationCount` field and
  three milestone tiers: `seed` (0), `first_five` (1–4), `first_ten`
  (5–9). Campaigns with 10+ donations "graduate" off the board entirely.
- Rotation logic updated to pick one candidate per tier rather than one
  campaign overall.

**Why:** Zero-donation visibility is only part of the problem — a
campaign with a couple of donors still needs a push before it reaches
real momentum. Tiering also creates a natural, visible "success state"
(graduation) that a single flag couldn't represent.

---

## 2026-09-06 — v1: Initial seed prototype

**Changed:**
- First working version: `campaigns.json` schema (id, name, communities,
  description, link, needsBoost flag, submittedDate, lastFeatured),
  `rotate.py` selection script, a GitHub Actions cron workflow to run it
  daily, and a static HTML widget to display the result.
- Established the core constraint driving every later design decision:
  no public API exists to verify live donation counts on GoFundMe or
  similar platforms, so any "automated" detection has to rely on
  self-reported data rather than scraping.

**Why:** First attempt at automating visibility for zero-traction
fundraising campaigns, prompted by the "sites with zero donors stay that
way" algorithmic-visibility problem.

---

## Template for future entries

```
## YYYY-MM-DD — short title

**Changed:**
- ...

**Why:**
- ...
```
