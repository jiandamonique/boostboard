# INTERNAL — Moderator Handbook
(Never commit this file or this folder to GitHub. Store offsite — see bottom.)

## Screening checklist, before anything reaches the picker

For every submission:
- [ ] Link loads and is a real, live fundraiser page (not a homepage, social
      profile, or dead link).
- [ ] Story is specific — names, dates, a concrete situation — not generic
      or copy-paste-able.
- [ ] Not a brand-new campaign with an unusually large goal and zero
      updates/backstory (not disqualifying alone — look closer).
- [ ] Quick search of the person/campaign name + "scam" turns up nothing.
- [ ] Same submitter email hasn't submitted multiple unrelated campaigns
      recently.

**Extra scrutiny for bare payment-handle submissions** (a Venmo/CashApp/
PayPal.me link with no platform-hosted story behind it — e.g. someone
just posting their handle on social media): these carry more scam risk
than a GoFundMe/Indiegogo page, since there's no third-party platform
story, identity signal, or update history to check against. For these:
- [ ] Cross-check the handle against the name/social account it was
      shared from — a mismatch is a red flag.
- [ ] Prefer submissions where the request came with enough personal
      context to feel real, not just a bare payment link.
- [ ] When in doubt, ask a clarifying question before approving rather
      than approving on the strength of the payment link alone.

**Current stance on bare payment-handle submissions, stated plainly
(v72)**: public copy (the intake form's field description, the
"Common fundraising platforms" reference page) still says these are
accepted, and that text is staying as-is on purpose — no public policy
change. What's actually different in practice: **treat every bare
payment-handle submission as a case-by-case discretionary approval,
not a blanket "yes" just because the format is technically accepted.**
The concern isn't the format itself, it's volume — a link with no
platform-hosted story is also the easiest thing for a bad-faith
submitter to mass-produce, and vetting one of these properly takes
real moderator judgment, not a checklist that scales. If submissions
of this type start arriving in meaningful numbers, that's a signal to
revisit the public copy, not a reason to lower the bar to keep up.

**Fallback-eligible campaigns (low percent-of-goal or flagged low
engagement)** get the exact same checklist above — passing 10 donors or
having a public campaign page doesn't lower the scrutiny bar. Two extra
considerations specific to this pathway:
- [ ] If setting `lowEngagementFlag`, this has no computed check behind
      it at all — it's your judgment call alone. Be honest about
      whether a campaign genuinely seems overlooked versus just wanting
      to include something because the normal pool is thin that day.
- [ ] Don't reach for the fallback pathway routinely just to keep the
      board full — it exists for genuine cases the donor-count tiers
      miss, not as a way to pad out a slow day.

If two or more boxes are unchecked, hold the submission and ask a
clarifying question via email before approving.

## Handling a report

**Keep this mechanic backend-only — never explain publicly that a report
instantly hides a campaign, even a pinned one.** Malicious reporting
(someone reporting a legitimate campaign just to knock it off the board)
is a real risk, and publicly documenting exactly how reports work only
makes that easier to exploit. The public site should say only that
reports are reviewed by a moderator — nothing about timing or effect.

1. On receiving a report (via the embedded report form), immediately set
   `reported: true` on that campaign in campaigns.json and republish. This
   pulls it from the public board automatically, pinned or not.
2. Investigate within [set your own real turnaround time here — e.g. 48
   hours on weekdays, longer on weekends given this is volunteer-run].
   **Treat this as a genuine priority, not a formality** — because a
   report hides the campaign instantly, a slow review means a
   maliciously-reported legitimate campaign sits invisible longer than
   it should.
3. Resolve one of two ways:
   - False alarm / resolved: set `reported: false`, log a one-line note
     here with the date and outcome for the next moderator.
   - Confirmed problem: remove the entry from campaigns.json entirely
     rather than leaving it flagged indefinitely.

**Watch for patterns suggesting bad-faith reporting**: the same reporter
(if identifiable) reporting multiple unrelated campaigns, a report with
no substantive reason given, or a report arriving suspiciously soon
after a campaign gets pinned/featured. None of these prove malice alone,
but they're worth weighing when deciding how fast to restore a campaign.

## Notifying featured campaign owners (good faith, no reply expected)

When a campaign is actually featured (hits the board or becomes the
hero), send a short courtesy note. This is good faith outreach, not a
request for anything — make that explicit in the message itself, and
don't treat a non-reply as anything other than normal.

**Why the wording matters, specifically**: a common scam pattern looks
exactly like a "good news" outreach message — "you've been selected for
a free donation, email us to claim it" — that then leads to an upsell
once the person responds. Boost Board's message needs to read as the
opposite of that on first glance: no claiming, no action required to
"unlock" anything, nothing that only makes sense if the person replies.
State plainly that it already happened or is about to happen regardless
of any response.

Two short variants, depending on timing:

**If the campaign is already live on the board:**

> Subject: Your campaign is featured on Boost Board
>
> Hi [name],
>
> Just an FYI — your campaign is currently featured on Boost Board:
> [link]. This already happened; there's nothing you need to do. If
> you'd like us to add or change anything about how it's shown, let us
> know — otherwise no reply needed at all.
>
> Boost Board is a small volunteer-run project that gives daily
> visibility to fundraising campaigns that haven't gotten much reach
> yet.
>
> Take care,
> The Boost Board team

**If a moderator found the campaign and is about to add it (sourced,
not self-submitted):**

> Subject: We're featuring your campaign on Boost Board
>
> Hi [name],
>
> We came across your campaign and we're planning to feature it on
> Boost Board, a small volunteer-run project that gives visibility to
> fundraisers that haven't gotten much reach yet: [link to Boost Board].
> This isn't something you need to respond to or do anything about — if
> you'd rather we didn't, or want us to add/change something first, just
> let us know.
>
> Take care,
> The Boost Board team

Keep the merge fields (`[name]`, `[link]`) consistent so this is easy to
template into an automated send later — the message is written to be
equally sendable by a human copy-pasting it today or a script firing it
automatically once the project can support that, without changing the
wording. Automation-friendly today just means: don't write anything into
this template that only makes sense coming from a human typing it live.

**Consequence for data retention**: this means submitter email can no
longer be deleted immediately after initial review, since the campaign
may not actually be featured until days or weeks later. See the updated
retention window in `INTERNAL_data-retention.md`.

## Random pick vs. recency guard

The moderator picker excludes anyone featured in the last 7 days from the
random pool automatically. Don't manually pin someone who was already
featured this week unless there's a specific editorial reason to.

## Succession / bus-factor

[Fill this in for real before this goes live with more than one person:]
- Where campaigns.json actually lives (repo name, hosting).
- Where the intake form's responses land (spreadsheet link, account).
- Who currently has moderator access and how a second person gets it.
- Where this document itself is stored offsite.

## Storage instructions for this file

Keep this folder (`internal-docs/`) out of any git repository entirely —
add `internal-docs/` and `INTERNAL_*` to your `.gitignore` as a backstop,
but the real safeguard is simply never putting this folder inside a repo
folder in the first place. Zip this folder separately from your public
site files and store the zip somewhere offsite (a password manager's file
storage, an encrypted drive, or a private cloud folder that isn't linked
from anything public).

## Sourcing campaigns manually (not just waiting on submissions)

Since no platform offers a public filter for "zero donations" (confirmed
for GoFundMe specifically — their own help docs only mention filtering
by purpose, location, and closeness to goal, nothing for recency or
amount raised), finding candidates proactively means manual searching.
This applies to any platform, not just GoFundMe — substitute the domain.

**Techniques, roughly in order of effort:**
- Site-restricted web search (e.g. `site:gofundme.com` combined with a
  need-related term) surfaces pages Google has indexed, which skews
  toward pages that already have *some* traffic — useful for finding
  campaigns generally, less useful specifically for brand-new/zero ones.
- GoFundMe's own search supports a native "fundraisers near you"
  location filter — a legitimate, built-in way to browse local
  campaigns without needing an external workaround. Same caveat as the
  rest of platform search: it tends to favor campaigns already getting
  engagement, so a brand-new local page may still rank low even with
  location narrowing it down.
- Browsing a platform's own category or "recently started" listings
  (where available) is the more direct path to genuinely new, likely-
  zero campaigns, since a brand-new listing hasn't had time to accumulate
  donations yet.
- Some categories statistically see less organic traction than others
  (e.g. individual medical/emergency requests from people with smaller
  or less-connected personal networks) — worth keeping in mind as a
  place to look, not as a guarantee any specific campaign there is
  actually at zero.

**Consent is different for sourced campaigns than submitted ones.** A
self-submitted campaign's owner already expects to hear from Boost
Board. Someone whose campaign you found and added has no idea this
happened until you tell them — which makes the good-faith notification
(see the outreach template earlier in this doc) not just a nice touch
for sourced campaigns, but the *only* way they learn about it. Send it
promptly, not as an afterthought, and apply the same screening
checklist to sourced campaigns as submitted ones — finding it yourself
doesn't lower the scrutiny bar.

**Why this can't just be automated.** Platforms have a structural reason
to keep zero-donation campaigns out of search and discovery surfaces:
letting every brand-new, unpromoted page appear in search results would
flood users with untested, unverified listings. This isn't a bug to work
around — from the platform's perspective, it's spam prevention. One
partial workaround is adding phrase-matching terms like `"$0 raised"` or
`"0% raised"` to a web search query, which occasionally surfaces a live
example through a search engine's own indexing rather than the
platform's. But this only catches whatever a search engine happened to
crawl and index, it's inherently incomplete, and anything found this way
is a moving target — a campaign showing as $0 in a stale search result
may have already received its first donation by the time it's actually
checked. Treat this as one more manual technique to try occasionally,
not a repeatable pipeline, and always re-verify the current state of
anything found this way before adding it (same screening checklist
applies regardless of how a campaign was found).

**Adding a sourced campaign** uses the same picker tool as any
submission — paste what you found into "Add a new campaign," or fill
the fields by hand if there's nothing to paste.

## Extracting a campaign's real photo from a saved page (confirmed feasible)

If a campaign page is saved as a single-file webpage (`.mhtml` — most
browsers offer "Save As → Webpage, Single File") and uploaded, the
actual photo the page uses (the one referenced by its `og:image` tag)
is embedded inside that file as a real, extractable image — not just a
link to it. This means a campaign's real photo can be pulled directly
from a saved copy of its page, rather than needing a separately hosted
image URL or manually right-clicking "copy image address" from a live
page.

Confirmed working in practice: extracted and used the real photos for
Jaye's and gaynor/Midnight's campaigns this way, matching each page's
`og:image` exactly. Save the extracted image as its own file (e.g.
`campaign-name.webp`) in the repo, same as any other `imageUrl` — still
subject to the same manual-sourcing screening as everything else; the
photo being real doesn't change the vetting needed on the rest of the
submission.
