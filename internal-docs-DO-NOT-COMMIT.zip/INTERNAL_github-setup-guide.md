# INTERNAL — ELI5 GitHub Setup Guide (Public + Private Repos)
(Never commit this file or this folder to GitHub.)

No command line needed anywhere in this guide — everything happens by
clicking around on github.com.

## Part 1 — The public site (the repo everyone can see)

1. Go to github.com and make a free account if you don't have one.
2. Click the **+** in the top right → **New repository**.
3. Name it anything (e.g. `boost-board`). Leave it **Public**. Click
   **Create repository**.

   **Confirmed real name: this public repo is called `boostboard`.**

   **Description**: "A volunteer-run tool that gives daily visibility to
   fundraising campaigns stuck at zero (or minimal percentage)
   donations."

   **Topics** (set later via the gear icon next to "About" on the
   repo's main page): `crowdfunding`, `gofundme`, `mutual-aid`,
   `fundraising`, `nonprofit`, `volunteer`, `static-site`,
   `github-pages`, `javascript`, `accessibility`.
4. On the new repo's page, click **uploading an existing file** (or
   drag files onto the page).
5. Unzip `live-site-files.zip` on your computer first, then drag *all*
   the files and folders inside it (not the zip itself) onto that
   upload area. Scroll down, click **Commit changes**.
6. Go to the repo's **Settings** tab → **Pages** (left sidebar) → under
   "Branch," pick `main` and `/ (root)` → **Save**.
7. Wait a minute or two, then refresh that same Pages settings page —
   it'll show you the live URL (something like
   `https://yourname.github.io/boost-board/`). That's your actual site.

## Part 2 — The private notifier (never shows this one to anyone)

This is a **separate** repo — don't put these files in the repo above.

1. Click **+** → **New repository** again.
2. Name it anything (e.g. `boost-board-private`). This time click
   **Private** instead of Public. Click **Create repository**.
3. Unzip `private-notifier-repo.zip`, upload all its files the same way
   as Part 1, step 4–5. **The `CAMPAIGNS_URL` inside `notify-
   subscribers.js` is already set to your real repo
   (`jiandamonique/boostboard`) — nothing to edit here, skip straight to
   step 4.**
4. Go to this repo's **Settings** → **Secrets and variables** →
   **Actions** → **New repository secret**, and add these five, one at
   a time (name exactly as shown, value is yours to fill in):
   - `SMTP_HOST` — e.g. `smtp.gmail.com` if using Gmail
   - `SMTP_PORT` — `587`
   - `SMTP_USER` — the email address you're sending from
   - `SMTP_PASS` — an **App Password** (myaccount.google.com/apppasswords), not your real password. **Requires 2-Step Verification to be turned on first** at myaccount.google.com/security — Google won't show the App Passwords option otherwise. The generated code is shown once; copy it immediately, there's no way to view it again later.
   - `FROM_EMAIL` — usually the same as `SMTP_USER`

**Each secret's Name field must be typed exactly as shown above** —
`SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `FROM_EMAIL`, five
separate secrets. A secret named anything else (a nickname, etc.) won't
be found by the script, since it looks these up by exact name.

That's it — a scheduled job (already set up in the files you uploaded)
will run automatically every day from here on.

## Troubleshooting: "I created the repo but it's empty"

This is expected right after creating a repo — creating it and
uploading files are two separate steps. On the repo's main page (when
it's empty), GitHub shows an **"uploading an existing file"** link
instead of a file list — click that, then drag the unzipped contents
onto the page and **Commit changes**. See Part 2 above for the private
repo specifically, or Part 1 for the public one.

## Troubleshooting: "it won't let me create the .github folder"

This isn't a GitHub bug — it's your operating system's upload/file-picker
dialog hiding folders that start with a dot (`.github` counts as
"hidden"). Drag-and-drop from Finder/Explorer often can't see it either,
for the same reason.

**Fix**: don't try to upload the folder. Instead, on the repo's page:
1. **Add file** → **Create new file**.
2. Type the full path with slashes directly into the filename box, e.g.
   `.github/workflows/daily-rss.yml` — GitHub creates both folders
   automatically the moment you type the slashes.
3. Paste the file's content into the text area, **Commit changes**.

(To see the hidden folder yourself instead: Mac, `Cmd+Shift+.` in a file
dialog; Windows, File Explorer's View menu → "Hidden items.")

## Switching out the placeholder/dummy content

- **The sample campaigns**: on github.com, open `campaigns.json` in the
  *public* repo, click the pencil ✏️ to edit, delete the sample entries,
  replace with your real ones (or use `moderator-picker.html` on your
  own computer to build the file, then upload it here to replace the
  old one — Part 1, step 4–5 again, same filename overwrites it).
- **The GoFundMe / "support the app" links** (two spots):
  1. Open `credits.html`, edit, find `href="#"` next to `Support the
     app →`, replace `#` with your real GoFundMe URL in quotes.
  2. Same file, find the second `href="#"` next to `Get notified →`
     (only do this once you have a real signup form to link to).
  3. Open `overlay-generator.html`, edit, find the line
     `const BOOST_BOARD_BASE = ...` near the top of its script and
     already filled in — real live URL confirmed as `https://jiandamonique.github.io/boostboard/` (repo name
     `boostboard` is already filled in correctly).
- Every time you edit a file this way and click **Commit changes**, the
  live site updates within a minute or two — no extra step needed.
