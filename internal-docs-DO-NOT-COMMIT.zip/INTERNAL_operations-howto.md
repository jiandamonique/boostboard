# INTERNAL — How It's Built, How It Runs
(Never commit this file or this folder to GitHub.)

## Tech stack & code overview

**Stack**: plain HTML, CSS, and JavaScript. No frameworks (no React, no
Vue), no build step, no npm/node dependencies, no bundler. The only
external resource pulled in is the Google Fonts CDN for Lora, Source Sans
3, and JetBrains Mono. This is deliberate — anyone with a text editor and
a browser can read, modify, and run every part of this without installing
anything.

**Files and what each one does**:

- `campaigns.json` — the entire dataset. Plain JSON array, one object per
  campaign. No database, no API — this file *is* the backend. See the
  backend architecture doc for the exact schema.
- `board-data.js` — shared data + selection logic (`tierOf()`,
  `selectSection()`, `daysSinceEpoch()`, `computeToday()`). Both
  `index.html` and `board.html` load this and call `computeToday()`,
  which returns `{ hero, zeroSection, tlcSection }`. One source of
  truth instead of duplicating the dataset/rotation math per page.
- `index.html` — the actual homepage. Renders only the hero (via
  `computeToday().hero`) plus a short intro. Loads `board-data.js` via a
  plain (non-deferred) `<script src>` placed directly before its own
  inline script, so the data is available synchronously when needed.
- `board.html` — "The Board." Renders the Zero Donations and TLC
  sections from the same `computeToday()` call; does not re-render the
  hero (already shown on the homepage), only uses `hero.id` to exclude
  it from the grids and `hero.link` for the "donate to today's featured
  campaign" button.
- `nav.js` / `footer.js` — shared site chrome. `nav.js` defines the page
  list once and exposes it as `window.BOOST_BOARD_PAGES`; `footer.js`
  reads that same list for the bottom sitemap. Both load as `defer`
  scripts in `<head>` on every public page. As of v30, `nav.js` renders
  as a fixed left-hand sidebar (220px wide) on screens ≥700px, adding
  `padding-left` to `<body>` via an injected style so page content
  shifts right rather than being covered. Below 700px, it collapses back
  to the original horizontal top bar — a fixed sidebar at phone width
  would leave too little room for actual content. Same link list and
  active-state logic either way, just different CSS.
- `random-campaign-widget.js` — small random-campaign widget appended
  to the bottom of every page (after the footer). Loads as `defer`,
  after `board-data.js` in the script order.
- `about.html`, `archive.html`, `credits.html`, `helpful-fundraising-
  ideas.html`, `overlay-generator.html`, `fundraising-platforms.html`,
  `emergency-help.html`, `roadmap.html`, `mods.html` — content pages,
  same shared nav/footer/widget pattern. `overlay-generator.html`
  additionally generates a progress graphic + QR code, and an
  `<iframe>` embed-code snippet pointing at
  `embed-widget.html`.
- `embed-widget.html` — minimal, no nav/footer, meant only to be
  embedded via `<iframe>` on external sites. Supports `?mode=hero` or
  `?mode=random` via URL parameter.
- `generate-rss.js` — recomputes the hero from `campaigns.json` (same
  logic as `board-data.js`, duplicated rather than shared since this
  runs in Node, not a browser) and writes `rss.xml`. Run daily by
  `.github/workflows/daily-rss.yml`.
- `notify-subscribers.js` — same hero recomputation, compares against
  `last-notified.json` to avoid duplicate emails if the same campaign
  stays featured across multiple days, and calls the Resend API to
  broadcast to a subscriber audience if the hero changed. Requires
  `RESEND_API_KEY` and `RESEND_AUDIENCE_ID` as GitHub Secrets — fails
  loudly (exit code 1) if either is missing, rather than silently
  skipping. Run by the same daily workflow, after `generate-rss.js`.
- `moderator-picker.html` — the internal tool, also a single
  self-contained file. Opens directly in a browser via double-click for
  everything, including the "Smart parse" button — it tries the AI path
  first and falls back to a free offline parser automatically if no API
  key is available (see below). Key pieces:
  - A `<table>` rendered from the loaded campaign list, rebuilt by
    `render()` every time something changes.
  - Two click-toggles (`data-action="pin"` / `data-action="report"`) that
    flip booleans directly on the in-memory `campaigns` array.
  - An editable text input per row for `imageUrl`, saved via a `change`
    listener.
  - `parseSubmission(text)` — label-based parser, matches "Question/
    Answer" paragraph pairs. Deterministic, no network call, works
    anywhere this file is opened.
  - `fuzzyParse(text)` — free, offline fallback for completely freeform
    text (a tweet, a bare Venmo handle, no labels at all). Regex-based:
    grabs the first URL (recognizes bare payment-platform domains like
    `venmo.com/...` without requiring `http://`), first email, a
    donation-count mention if phrased recognizably, and guesses the name
    from the first line that isn't a link or email. No network call, no
    cost, works standalone. Meant to be double-checked, same as the
    label parser — it's pattern matching, not understanding.
  - `smartParse(text)` — AI-based parser for completely freeform text,
    via a direct Claude API call. **Only works while this tool is
    running as a Claude artifact** — that context supplies the API key
    invisibly. When it's unavailable (standalone file, no key, or a
    network error), the button automatically falls back to
    `fuzzyParse()` instead of failing — the form shows which method was
    used ("AI" vs. "basic pattern matching") so you know how much to
    double-check.
  - `updatePreview()` — live WYSIWYG card preview in the add-form,
    updates on every keystroke in name/description/communities/donation
    count, so you see roughly what the public card will look like before
    committing to adding it.
  - `randomPickBtn` handler — filters by tier, excludes reported entries
    and anyone within `RECENCY_GUARD_DAYS` (hardcoded to 7) of their last
    feature date, then picks uniformly at random from what's left.
  - `overrideBtn` handler — the manual escape hatch, looks up a typed-in
    `id` directly and force-pins it, bypassing every filter.
  - `downloadBtn` handler — serializes the in-memory array back to JSON
    and triggers a browser download; this is the only way changes leave
    the tool. Nothing here writes back to a server or repo automatically.

**Running it locally**: `moderator-picker.html` can be opened directly
from disk (`file://`) — it doesn't fetch anything external besides
fonts. `index.html` and `board.html` also work fine via `file://` since
`board-data.js` is inlined data, not a `fetch()` call.

**Deploying**: push these files to a GitHub repo, enable GitHub Pages in
the repo's Settings → Pages. `index.html` is already correctly named to
serve as the homepage automatically — no rename needed (unlike earlier
versions of this project, before the landing-page/board split). No
build step, no CI required beyond the two scheduled Actions
(`daily-rss.yml`) already in place.

## What this actually is, in one paragraph

A static site (GitHub Pages) with one shared JSON file as the entire
"database." A moderator manually reviews and adds submissions to that
file; the public page then automatically rotates who's featured each day
using logic baked into the page itself — no server, no scheduled job, no
hosting cost beyond what GitHub Pages already gives for free.

## Day-to-day operation

## Autonomous / unattended operation

If no moderator touches anything for an extended period (confirmed: 7+
days), the public board keeps working correctly:
- Rotation continues — it's computed live in each visitor's browser from
  the current date, with no server or cron job that could go down.
- Pinned entries stay pinned indefinitely (no auto-expiry) until someone
  manually unpins them.
- Reported entries stay correctly hidden the entire time — this is the
  fail-closed design working as intended, not a gap.

What genuinely requires a human, and queues up untouched otherwise:
- New submissions don't get approved — they just sit unreviewed.
- Reports don't get resolved — the campaign stays hidden (correctly)
  until someone investigates, which could unfairly sideline a
  maliciously-reported legitimate campaign for as long as nobody looks.

## Campaign Tools page (`overlay-generator.html`)

A platform-agnostic version of GoFundMe's own "Live fundraising tools"
overlays (progress bar, QR code) — but for any campaign, since most
platforms (bare Venmo/CashApp links especially) have no equivalent.

- Self-reported and manually refreshed, same honesty constraint as
  everything else here — there's no live donation API for any platform,
  so this can't be more "live" than the person regenerating it by hand.
- Progress graphic is built as raw SVG (not styled HTML rendered to
  canvas) specifically so it rasterizes to PNG reliably via
  `canvas.drawImage()` — an HTML+CSS approach would need a heavier
  library (html2canvas or similar) and risks web-font loading issues
  during rasterization. Trade-off: the exported graphic uses generic
  serif/sans-serif fonts, not the site's Lora/Source Sans, since custom
  web fonts inside an SVG data URI aren't reliably available at the
  moment `canvas.drawImage()` fires.
- QR code is generated via a free third-party service
  (`api.qrserver.com`), not generated locally — simplest reliable option
  without shipping a full QR-encoding library. The `download` attribute
  on a cross-origin image isn't honored by all browsers (some just open
  it in a new tab), so the page includes a fallback instruction to
  right-click and save manually.
- "Copy HTML embed code" is included for people who can paste raw HTML
  somewhere (their own site, a Linktree custom block) — but most social
  platforms don't accept it, which the copy-confirmation message says
  explicitly so people aren't confused when pasting it into an
  Instagram bio does nothing.

## Multi-page architecture (confirmed, not a build-vs-SPA question)

GitHub Pages serves any number of static files with no special
multi-page configuration — this was never actually in question. Explicit
decision: **stay vanilla multi-page, not a React/tabs SPA.** Reasoning:
a build step or in-browser transpiling contradicts the zero-dependency,
anyone-can-open-and-edit philosophy carried over from the original
artist-directory repo, and separate pages are individually shareable/
linkable in a way a single-URL tabbed SPA isn't.

**`nav.js`** — the one piece that actually was missing: a shared
navigation bar, injected via a single script rather than duplicated into
every HTML file by hand. Included via `<script src="./nav.js" defer>`
in the `<head>` of every public page except `moderator-picker.html`
(internal tool, not part of the public navigation flow). Highlights the
current page by matching `window.location.pathname` against its own
link list — update the `links` array in `nav.js` if a page is renamed or
a new one is added, or the nav will silently not highlight it (still
functional, just no active-state indicator).

**Homepage naming**: GitHub Pages serves whichever file is named
`index.html` at the repo root as the site's homepage. `spotlight-widget-
demo.html` needs to be renamed to `index.html` (or Pages settings
pointed at it specifically) before actual deployment — it's still named
from its original demo-file origin.

## Pre-launch checklist

Consolidated from action items flagged throughout development — check
each off before actually publishing, don't rely on remembering them.

**⚠ Deployment sync check (confirmed stale as of this session)**: fetching
the live site directly showed the homepage still has the *old* intro
copy (pre-v40 wording) — meaning the public `boostboard` repo hasn't
been re-uploaded with the many rounds of changes since an early upload.
**Before anything else**: re-upload the current `live-site-files.zip`
contents to the public repo, overwriting the existing files, so the
live site actually matches everything documented here.

**File/deployment mechanics:**
- [x] ~~Rename `spotlight-widget-demo.html` → `index.html`~~ — superseded:
      `index.html` is now a purpose-built simple landing page (v27), not
      a rename of the old combined page. The old file is deleted.
- [ ] If any file gets renamed or a new page gets added after that,
      update the `links` array in `nav.js` to match — `footer.js` reads
      the same list automatically via `window.BOOST_BOARD_PAGES`, so
      only `nav.js` needs editing, not both.
- [ ] Decide on and wire up an actual email-sending provider for the RSS
      feed (`rss.xml`, generated daily by `.github/workflows/daily-
      rss.yml`) once a subscriber list exists — **built natively via
      SMTP (nodemailer), no third-party account.** `notify-
      subscribers.js` lives in a SEPARATE PRIVATE repo (never the
      public site repo — it holds subscriber emails). Still needed:
      actually create that private repo from `private-notifier-repo/`,
      update `CAMPAIGNS_URL` to the real public repo's raw URL, add
      SMTP secrets (an email account's host/port/user/App Password),
      and set up the sending account (Gmail App Password is the
      simplest path).
- [x] ~~Build the actual subscriber signup flow~~ — `subscribe.html`
      now exists (v65), `credits.html`'s "Get notified" button points to
      it. **Still needed**: create the real Google Form (see "Subscriber
      signup form setup" section below) and paste its embed URL into
      `subscribe.html`'s iframe — the page currently shows an honest
      placeholder note instead of a broken link.
- [ ] Build the Google Form for campaign intake using the exact
      question wording documented in the operations doc's "Google Form
      intake setup" section, and a second Form (or a branching version)
      for reports, with the reason field described there.

**Real URLs still needed (currently `href="#"` placeholders):**
- [ ] `credits.html` — the "Support the app →" give-button needs the
      real GoFundMe campaign URL once it exists.
- [x] ~~`board.html` — the report link is a demo-only `alert()`~~ —
      now redirects to `submit.html?report=<id>&name=<name>`, which
      detects the params and shows the reported campaign's name plus a
      banner pointing to the "Anything else?" freeform question.
      **Still needs**: add the "What's this about?" and "Details"
      questions to the live Google Form itself (see the Google Form
      intake setup section below, v58) — this wasn't done via chat
      since it requires editing the form directly in your Google
      account.
- [ ] Confirm the "Donate to today's featured campaign" link (already
      wired dynamically to each day's hero campaign via JS) doesn't
      need a manual URL — it shouldn't, but verify on first real deploy.
- [ ] `overlay-generator.html` — `BOOST_BOARD_BASE` is set to
      `https://jiandamonique.github.io/boostboard/`, now confirmed and already filled in (repo name
      confirmed) — just fill in the real GitHub username, or every
      generated `<iframe>` snippet points nowhere.
- [ ] `credits.html` — "Get notified →" button for the zero-donation
      email alert is still `href="#"`, pending the provider decision in
      the RSS/email section above.

**Intake & moderation infrastructure (not yet built, per backend doc):**
- [ ] Actual submission intake form (Google Form/Formspree, embedded —
      not a GitHub Issue, per earlier decision on submission friction).
- [ ] Report-intake form, same mechanism, pre-filled with campaign ID.
      **Needs a reason field** distinguishing "concern" (should set
      `reported: true`) from "this campaign already has donations" or
      other informational updates (should NOT hide the campaign — see
      backend doc's Report Handling section).
- [ ] Confirm intake form question wording matches the parser's
      `FIELD_KEYS` labels (see "Intake form field labels" below) so
      pasted responses actually parse.

**Review/compliance (human-professional items, not automatable):**
- [ ] Privacy policy (`INTERNAL_privacy-policy-DRAFT.md`) reviewed by
      an actual lawyer before publishing — check a legal aid clinic
      first per the funding worksheet's reasoning.
- [ ] Real accessibility audit completed, ideally by an auditor from
      one of the communities this serves.

**Content still needed:**
- [x] ~~Build the actual Google Form~~ — done, embedded live in
      `submit.html`.
- [ ] Fill in real names/handles on the credits page's "Thanks to" list
      (currently placeholder text).
- [ ] Add volunteer/team campaign entries to `credits.html`'s
      `volunteerCampaigns` array when there are any (currently empty,
      shows "None listed right now").
- [ ] Populate `success-stories.html`'s `successStories` array as real
      stories come in — the current empty state is intentional, not a
      placeholder to replace with dummy content.
- [ ] Finalize "First donor" naming (leaning "First Encourager") and
      apply it consistently if/when adopted into copy.
- [x] ~~Finalize GFM campaign goal amount~~ — recommended $1,350, lean
      3-month scenario. Title, description, and a LinkedIn blurb are
      fully drafted in `INTERNAL_gofundme-campaign-plan.md` — ready to
      copy-paste once the account/campaign itself is created.

## Real Google Form (v42)

Live form: `https://docs.google.com/forms/d/e/1FAIpQLSf9ThdOcUj8fxX8VaZcT_aer0f53cIrZy3NVNv-ZwwKumJi9A/viewform`
— embedded in `submit.html` via `?embedded=true`, replacing the earlier
placeholder. Confirmed the form does not expose the owner's account
email to respondents (checked by reading the live form's actual
content). Noted a minor redundancy worth cleaning up: the form
currently has both Google's automatic "Email" field and a separate
custom "Your email" question — not broken, just duplicate, left as the
form owner's call to simplify or not.

## Google Form intake setup (v60 — as actually built)

Current live question order:

1. **How can we help?** (Multiple choice, required: "A new campaign to
   submit" / "A concern about a listed campaign" / "This campaign
   already has donations, please update" / "Something else"). Renamed
   from the original "What's this about?" — the picker's parser
   recognizes both labels, so nothing broke when you renamed it, but
   use "How can we help?" going forward. **Confirm this question's
   Required toggle is on** (bottom-right of the question editor) — if
   it's ever left blank, the picker defaults to treating the response
   as a new campaign, which would silently misroute an actual report.
2. **Campaign name** (Short answer, required).
3. **Your name** (Short answer, optional) — added so submissions and
   reports feel less anonymous/impersonal. Add a description on this
   question (⋮ menu → Description): "For our reference only, in case
   we need to follow up — never published or shared publicly." Shown to
   the moderator alongside the email for follow-up only; never saved to
   `campaigns.json`.
4. **Fundraiser link** (Short answer, required) — any platform/payment
   link is fine, including a bare Venmo/CashApp/PayPal.me handle.
5. **Communities** (Short answer, optional) — "Comma-separated, e.g.
   'trans, disabled' — leave blank if you'd rather not say."
6. **Description** (Paragraph, required) — "A sentence or two is
   plenty."
7. **Current donation count** (Short answer, required) — "Just a
   number, even if it's 0."
8. **Details / Anything else?** (Paragraph, optional) — used by reports
   for specifics; blank on a normal new-campaign submission.
9. **Email** — use Google Forms' own built-in email field (Settings →
   Responses → "Collect email addresses" → **Responder input**, NOT
   "Verified"). Responder input does not require a Google account or
   sign-in, so it doesn't reintroduce the sign-in friction this project
   deliberately avoided — it just adds a validated email field Forms
   manages for you. **Still to do on the live form**: delete the
   separate custom "Your email" short-answer question once the
   built-in field is turned on — it's now fully redundant. This field
   appears in exported responses as "Email Address," which the
   picker's parser already recognizes.

**Privacy note text — add to the form's own top-level description**
(the box under the form title, before any questions), rather than
per-question, since Google's built-in email field generally doesn't
support a custom per-question description the way "Your name" does:
"Your name and email are just for our reference, in case we need to
follow up — neither is ever published or shared publicly." This covers
both fields from one place regardless of which fields support their own
description text.

**Form settings:**
- Settings → Responses → sign-in NOT required (see above — Responder
  input mode keeps this true even with automated email collection).
- Responses → linked to a private Google Sheet for review — **live
  spreadsheet**: https://docs.google.com/spreadsheets/d/1o2x9yPLOy9rP9ZdK4pHc-tX0Eo_wHswZkLM4vC1YyzE/edit
  — **private to the moderator, never share this link or commit it
  anywhere public.**
- "Limit to 1 response" OFF (a legitimate submitter might need to
  submit more than once, or fix a mistake by resubmitting).

**Getting a response into the picker**: open the linked spreadsheet (or
the Form's own "Responses" tab), copy one full response's text, paste
it into the picker's single paste box, click "Parse pasted text
(labels)." It routes itself to either the add-campaign form or the
report view based on the "How can we help?" answer — see the backend
doc's Report Handling section for exactly how.

## Subscriber signup form setup (v65 — `subscribe.html` built, form not yet created)

This is a completely separate Google Form from the campaign intake one
— much simpler, only collecting an email (and optionally a name) for
the daily zero-donation alert.

1. Create a new Google Form with just:
   - **Email** — use Google's built-in field (Settings → Responses →
     "Collect email addresses" → **Responder input**, same reasoning as
     the intake form: no sign-in required).
   - **Your name** (Short answer, optional) — nice-to-have, not required.
2. Settings → Responses → sign-in NOT required, "Limit to 1 response"
   OFF (someone might resubscribe after unsubscribing).
3. Get the embeddable form URL (Send → the `<>` embed icon → copy the
   iframe src), then open `subscribe.html`, uncomment the HTML-commented
   `.form-panel` block, and replace `PASTE_REAL_EMBED_URL_HERE` with
   that real URL. Delete the placeholder `.placeholder-note` div once
   this is done — it's only there so the page never shows a silently
   broken form.
4. **Getting a new signup into `subscribers.json`**: open the form's
   linked spreadsheet, copy the email (and name, if given), and add it
   as a plain string to the JSON array in the private repo's
   `subscribers.json` — manual copy-paste is fine at this scale. A
   scripted bridge (auto-appending new rows) is the automatable version
   of this step, not yet built, and not urgent unless signup volume
   makes manual copying painful.

## Intake form field labels (must match the parser)

The moderator picker's paste-and-parse feature recognizes these labels
as the first line of a paragraph — whatever comes after (until the next
blank line) becomes that field's value. If you change the intake form's
questions, update `FIELD_KEYS` in `moderator-picker.html` to match, or
the parser will silently miss that field (it always falls back to a
blank, editable field, never breaks).

- **Campaign name** / Name / Title
- **Fundraiser link** / Link / URL / Campaign link
- **Communities** / Community / Tags
- **Description** / Story / Summary
- **Current donation count** / Donation count / Donations
- **Submitter email** / Email / Your email / Contact email

Whatever the intake form actually asks, keep the question text close to
one of these so pasting the response straight in parses correctly. The
parsed email is shown to you for follow-up only — it's never written
into `campaigns.json`, consistent with the data-retention policy.

## Claude-assisted campaign entry (a third way to add campaigns)

Alongside the moderator picker and the (future) Google Form, campaigns
can also be added by pasting raw information directly into a Claude
conversation and asking Claude to structure it into the schema and
update `campaigns.json` directly. This is genuinely useful for
replacing the placeholder/sample data with real campaigns quickly,
since Claude can extrapolate missing fields (guess a reasonable
`submittedDate`, infer `communities` tags from context, etc.) the same
way the picker's AI smart-parse does, but conversationally rather than
through the tool's UI.

**How it works in practice**: paste whatever you have — a link, a
description, screenshots, anything — into the chat. Claude fills in the
schema (see Data Model in the backend doc), asks about anything
genuinely ambiguous rather than guessing, and directly edits
`campaigns.json` (and keeps `board-data.js`'s and `moderator-
picker.html`'s inline copies of the same data in sync — a real bug hit
once already from an imprecise sync, see the v33 changelog entry, so
always verify by counting entries after, not just checking syntax).

This doesn't replace the screening checklist — same scrutiny applies
regardless of which of the three intake paths a campaign came through.

## Adding a submission (paste-and-parse, or manual)

1. Open `moderator-picker.html`, load the current `campaigns.json`.
2. Copy the full text of a submission (e.g. from a Google Form response
   email) and paste it into the "Add a new campaign" box, then either
   click "Parse pasted text (labels)" for the fast, deterministic path,
   or "Smart parse (AI)" if the text is freeform and doesn't match the
   labeled shape (only works while this tool is open as a Claude
   artifact — see the backend doc) — or click "Or start blank" to skip
   straight to the fields and type everything by hand.
3. Review the pre-filled fields (parsing is heuristic, not guaranteed —
   always check before adding, especially the link and donation count).
4. Click "Add to list." The new entry appears in the table below with
   today's date, `pinned: false`, `reported: false`.
5. From there it's business as usual: pin it, leave it to rotate
   naturally, or download and publish.

**When a submission comes in** (via the intake form, once built):
1. Run it through the screening checklist (see moderator handbook).
2. If it passes, add it via the picker's "Add a new campaign" section
   above (paste-and-parse or manual) rather than hand-editing the JSON
   file directly — same result, less error-prone.
3. Commit/publish the updated file. It'll enter the automatic rotation
   on its own from here — no further action needed unless you want to
   give it editorial priority.

**To give something editorial heat (cherry-pick):**
1. Open `moderator-picker.html` locally (just double-click it, it's a
   self-contained file — no install, no server).
2. Load the current `campaigns.json` via the file picker.
3. Click the star (☆) next to the entry to pin it.
4. Click "Download updated campaigns.json," then commit/publish that
   file in place of the old one.

**To use the random-pick helper instead of choosing yourself:**
1. Same tool, pick a tier from the dropdown, click "Pick one at random."
2. It automatically excludes anyone featured in the last 7 days.
3. Download and publish as above.

**To fix something urgently (glitch, wrong pick, needs immediate swap):**
1. Same tool, type the campaign's `id` into the override field, click
   "Force pin this ID."
2. This bypasses tier and recency-guard filters entirely — use sparingly,
   it's meant as an escape hatch, not a routine picking method.

**When a report comes in:**
1. Toggle the flag (⚑ → 🚩) on that entry in the picker tool. This sets
   `reported: true`.
2. Download, publish. The campaign disappears from the public board
   immediately, pin status notwithstanding.
3. Investigate per the moderator handbook's timeline. Either clear the
   flag (toggle back) or delete the entry entirely if confirmed bad.

## Publishing mechanics

"Publish" currently means: replace `campaigns.json` in the live GitHub
repo with the moderator tool's downloaded output, via a normal git
commit/push (or the GitHub web UI's "upload file" if you're not using git
directly). There is no automatic sync between the picker tool and the
live site — the download-then-upload step is manual by design, so nothing
publishes without a human's explicit action.

## Bringing on a second moderator

1. Share this document and the moderator handbook (offline — email as an
   attachment or a private, unlinked file, not a public link).
2. Give them access to wherever `campaigns.json` is actually hosted
   (repo collaborator access, or whatever your git setup is).
3. Give them the moderator-picker.html file (it's just a local file, no
   account/login needed to use it).
4. Walk them through one full cycle (add a submission → pin/random-pick →
   publish) live before they do it solo.

## Known fragility points, for future you

- Two people editing `campaigns.json` at the same time can silently
  overwrite each other's changes — there's no locking. At solo/small-team
  scale, just communicate before editing.
- Nothing currently validates that `campaigns.json` stays well-formed
  JSON after a hand-edit. A single typo can break the entire public
  board. Consider validating in a JSON linter before every publish.
- If this needs to run without you for a while (illness, vacation), the
  automatic rotation keeps working on its own — that's the point — but
  intake and reports will queue up until someone reviews them again.
