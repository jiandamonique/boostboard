# INTERNAL — Assistant Onboarding Prompt for Boost Board
(Never commit this file or this folder to GitHub.)

Paste this at the start of a new session (with Claude or any other
assistant) to bring it up to speed on this project without re-explaining
everything from scratch.

---

## What this project is

Boost Board is a small, volunteer-run app that gives daily visibility to
fundraising campaigns that haven't gotten much reach yet — the ones
algorithms bury because they have zero (or very few) donations. It shows
one featured campaign prominently each day plus a rotating grid of
others, all pulled from a shared dataset, with a human moderator
reviewing every submission before it goes live. It is explicitly **not**
a charity or nonprofit, and it never collects, holds, or moves money on
behalf of any campaign it features — it only links out to campaigns'
own pages.

## Two-file-split rule — never violate this

Everything splits into exactly two categories:
1. **Public / GitHub-safe**: the actual site files (HTML/JSON/CSS/JS),
   plus genuinely public-facing copy (README, guides, credits page).
   These ship in `live-site-files.zip`.
2. **Internal-only, never committed**: anything explaining *how* the
   system works, *why* decisions were made, moderator procedures, the
   changelog, planning docs, or this prompt itself. These live in
   `internal-docs/`, prefixed `INTERNAL_`, shipped separately in
   `internal-docs-DO-NOT-COMMIT.zip`, and a `.gitignore` in the public
   repo excludes `internal-docs/` and `INTERNAL_*` as a backstop.

**Standard delivery is three zips, always shipped together**:
`live-site-files.zip`, `private-notifier-repo.zip` (a genuinely separate
repo — contains `subscribers.json`, must stay permanently private, see
below), and `internal-docs-DO-NOT-COMMIT.zip`. Present all three
whenever any of them changes, not just the one that changed.

Reason: the project may relaunch later as a full site/NPO/product, so
the "recipe" (exact algorithms, screening criteria, mechanics) stays
private even though the working tool is public.

**Whenever you make a change, update both sides in the same pass**: the
relevant internal doc(s) (see list below) AND any public-facing copy
that changed, so nothing has to be remembered and reassembled later.

## Internal docs and what each one owns

- `INTERNAL_CHANGELOG.md` — one dated entry per meaningful change,
  newest at the top, "Changed" + "Why" format, template at the bottom.
  Update this every time, no exceptions — this is the project's memory
  across sessions.
- `INTERNAL_backend-architecture.md` — data schema, selection/rotation
  logic, known limitations, anything about how the system actually works.
- `INTERNAL_frontend-design.md` — design tokens, typography rationale,
  accessibility notes, visual language decisions.
- `INTERNAL_operations-howto.md` — the actual runbook: how to add a
  submission, handle a report, publish, onboard a second moderator, the
  full tech-stack/code walkthrough.
- `INTERNAL_moderator-handbook.md` — screening checklist, report-handling
  procedure, succession plan template.
- `INTERNAL_data-retention.md` — what's collected, retention windows, why.
- `INTERNAL_privacy-policy-DRAFT.md` — the actual public-facing privacy
  policy text, held back until deliberately ready to publish.
- `INTERNAL_gofundme-campaign-plan.md` — funding platform decisions,
  draft campaign copy, budget line items.
- `INTERNAL_indiegogo-campaign-plan.md` — superseded, kept for reference.

## Standing decisions (don't re-litigate these without being asked)

- **No LICENSE file** in the public repo — default copyright protects
  future relaunch options.
- **Sole proprietor**, not a company — funds raised anywhere are
  personal income for tax purposes; revisit fiscal sponsorship only if
  this grows past a side project.
- **GoFundMe, not Indiegogo** — donation-based (no reward tiers needed),
  no mandatory review-and-wait period.
- **Explicit non-charity/nonprofit disclaimer** in public copy — sets
  expectations, avoids any tax-deductibility implication.
- **No reward or perk may ever buy influence over which campaigns get
  featured.** Hard rule, no exceptions, applies to any future funding
  platform.
- **Pinning (editorial cherry-pick) is always manual** — a moderator
  decision, never automated. An optional public-facing reason can be
  attached when a campaign is pinned.
- **Reports always win, even over a pin** — hides a campaign instantly
  regardless of pin status. **This exact mechanic must never be
  explained in public-facing copy** — malicious reporting is a real
  risk, and documenting the rule publicly hands bad actors a precise way
  to exploit it. Public copy says only "reports are reviewed by a
  moderator."
- **No cute branding, anywhere, on anything user-facing.** Plain
  functional language only (e.g. "today's featured campaign," not a
  nickname). Internal codenames for mechanisms (e.g. "Inbox Zero" for
  the zero-donation hero-selection logic) are fine in internal docs and
  code comments, but must never leak into public copy.
- **Campaign links are payment-platform-agnostic** — GoFundMe, Indiegogo,
  a bare Venmo/CashApp/PayPal.me link all work identically. Bare
  payment-handle submissions get extra screening scrutiny (see moderator
  handbook) since there's no third-party platform vetting behind them.
- **Campaign images are always manually sourced**, never auto-fetched —
  cross-origin browser restrictions and scraping/ToS concerns rule out
  automatic fetching from a campaign's own page.
- **AI-assisted parsing degrades gracefully and costs nothing either
  way**: tries a live Claude API call (works free only while the tool
  runs as a Claude artifact), automatically falls back to a free,
  offline, regex-based parser if no API key is available. Never require
  an API key or paid access for this project's core tools to function.
- **The dataset is designed to support multiple front-doors later** —
  cross-posting the same campaign across different community-specific
  sites (autistic-focused, LGBTQIA-focused, etc.) via shared tags, one
  dataset, without merging the sites themselves into one "for everybody"
  experience.

## Working style for whoever/whatever picks this up

- Validate any code change actually runs (not just parses) before
  presenting it — this project has hit real bugs from partial edits
  before; test JS syntax and, where feasible, actual execution.
- State assumptions explicitly and proceed rather than stalling on minor
  ambiguity; ask only when a decision would be expensive to reverse.
- Keep public-facing copy plain, warm, and specific — no jargon, no cute
  naming, written for a reader who may be in a stressful situation.
- Always update the changelog. If in doubt about whether a change is
  "meaningful enough" to log, log it anyway — the log is cheap, losing
  context isn't.
