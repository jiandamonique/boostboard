# INTERNAL — Data Retention Notes
(Never commit this file or this folder to GitHub.)

## What we collect and why

- Submitter email: needed to follow up on a submission (approve, ask a
  question, notify when featured). Never published, never shared.
- Campaign details (name, description, link): public by nature — these
  come from an already-public fundraiser page.

## Retention

- Submitter emails: retain until the campaign has been featured at least
  once and the good-faith notification has been sent (see the moderator
  handbook's outreach template), OR the submission is declined —
  whichever comes first. Delete after that, unless actively investigating
  a report.
- This is longer than originally planned (previously: delete immediately
  after the approve/decline decision) because notifying someone at
  feature-time can happen days or weeks after their submission was
  approved — the email is needed to actually send that notification.
- If using a Google Form, periodically clear the response spreadsheet of
  emails for entries that have been both featured and notified.
- **Newsletter subscriber emails are a separate, more sensitive case.**
  They live in `subscribers.json` in a dedicated PRIVATE repository
  (never the public site repo — see the backend doc's native-SMTP
  section for why). Retain only while someone remains subscribed;
  process unsubscribe requests (currently: a reply to the notification
  email) by removing the address from that file promptly, not just
  marking it inactive.

## What this means for the public privacy policy

The public-facing policy should say, in plain terms: we collect an email
only to review your submission, we don't sell or share it, and we delete
it once your submission is processed. If that's not true in practice,
fix the practice rather than the wording.
