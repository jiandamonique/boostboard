# INTERNAL — Indiegogo Campaign Plan
**⚠ SUPERSEDED — switched to GoFundMe. See `INTERNAL_gofundme-campaign-plan.md`.**
Kept here for reference (reward-tier ideas may still be reusable if the
platform ever changes again).
(Never commit this file or this folder to GitHub.)

## Basics

- Sole proprietor launch — no separate business entity. Means: personal
  ID verification, personal bank account, funds are personal income for
  tax purposes. Revisit fiscal sponsorship if this grows past a personal
  side project (see cost breakdown, "fiscal sponsorship / entity setup"
  line item).
- Category: **confirmed — Community Projects → Human Rights or Wellness**
  over Tech & Innovation. Tech's subcategories are hardware/consumer
  product focused (audio, wearables, phones); this is a cause-oriented
  tool, and backers browsing causes are more likely to be in Community
  Projects. Confirm the live category list at actual project-creation
  time — Indiegogo has revised categories before.
- Duration: 24 hours to 60 days, set deliberately, not defaulted.
- Submit for review at least 7 days before desired launch; review itself
  can take up to 3 business days. Don't set a launch date without this
  buffer built in.

## Reward tiers (draft — refine before launch)

Hard rule for every tier: **rewards never buy influence over which
campaigns get featured.** No "pay to boost a specific campaign," no
"skip the queue" perk tied to a dollar amount — that would undercut the
entire fairness design of the rotation system. Every reward is about
supporting the project itself, never about the outcome of who gets
featured.

Draft tiers, cost-to-fulfill in parentheses:
- $[amount] — Name/pseudonym on a public Founding Supporters page (free)
- $[amount] — Digital "Community Champion" badge for their own social
  media (design time only)
- $[amount] — Early look at the code before public launch (free —
  already public-adjacent via GitHub)
- $[amount] — Printed or digital zine-style thank-you note (low cost)
- $[amount] — Invite to a behind-the-scenes update call / AMA (time only)
- $[amount] — Input on a low-stakes design choice (e.g. vote between two
  color palettes) (free)
- $[amount] — Physical stickers (material + shipping cost — only if
  budget allows; shipping to international backers adds real cost/
  complexity, decide scope here)

## Budget line items (from earlier discussion, for the page copy)

- Hosting & infrastructure (likely near-$0, list a small number anyway)
- Developer time
- Moderator stipends
- Content & copywriting
- Outreach & marketing
- Accessibility audit
- Legal consultation (privacy policy / ToS review)
- Fiscal sponsorship / entity setup (relevant given sole-proprietor status)
- App launch (only if genuinely in scope — separate clearly from current
  ask if it's a later phase)
- Contingency buffer

## Open decisions before drafting page copy

- Actual dollar amounts per reward tier.
- Total funding goal and whether "keep what you raise" or "all-or-nothing."
- Whether stickers/physical rewards are in scope given international
  shipping complexity.
- Final category confirmation at creation time.
