# INTERNAL — Privacy Policy (DRAFT, not yet published)
(Never commit this file or this folder to GitHub. This is meant to
eventually become a public-facing page — publish it deliberately when
ready, don't let it leak out early via a repo commit.)

---

## Privacy Policy — Boost Board

**What we collect**

When you submit a campaign, we ask for an email address so we can follow
up with you — to approve your submission, ask a clarifying question, or
let you know when you've been featured. We don't ask for anything else
about you personally; the campaign details you share (name, description,
link) come from your already-public fundraiser page.

**What we don't do**

We don't sell, share, rent, or otherwise pass your email address to any
third party for any purpose. We don't use it for marketing. We don't add
you to a mailing list.

**How long we keep it**

We keep your email until your campaign has been featured and we've sent
you a courtesy note letting you know (or until we decide not to feature
it, if sooner). After that, we delete it. If we're actively investigating
a report related to your campaign, we may retain it a bit longer while
that's ongoing.

**Reports**

If someone reports a campaign, we review it manually. We don't publish
who filed a report or share that information with the reported campaign.

**Volunteer-run, plainly stated**

This project is run by volunteers, not a company. We built this policy
to reflect what we actually do, not to sound official — if anything here
ever stops being true in practice, we'll fix the practice or update this
page, not the other way around.

**Questions**

[Contact method — e.g. "open an issue on our GitHub" or an email address]

---

## Notes for whoever publishes this (not part of the public text)

- Confirm the actual intake tool (Google Form/Formspree/etc.) doesn't
  independently log more than this policy promises (IP address,
  timestamp beyond what's needed, etc.) before publishing this page —
  the policy should match reality, not aspiration.
- If a fiscal sponsor or nonprofit entity forms later, this may need a
  legal review pass rather than staying purely volunteer-drafted.
