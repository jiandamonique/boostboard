# INTERNAL — GoFundMe Campaign Plan
(Never commit this file or this folder to GitHub.)

## LIVE (v71): https://www.gofundme.com/f/amplify-campaigns-waiting-for-a-first-yes

The campaign is live. This URL is now wired into `credits.html`'s
"Support the app →" button on the public site. Everywhere else in this
doc that still says "[GoFundMe link]" or similar is historical
drafting — the actual, current URL is the one on this line.

## Why GoFundMe over Indiegogo

- **Donation-based, and no perk/reward tiers are allowed at all** —
  confirmed directly against GoFundMe's own support documentation:
  organizers may not offer any good or service in exchange for a
  donation, on or off the platform. This isn't just "not required" the
  way it was under Indiegogo — GFM prohibits it outright, including
  non-monetary items like stickers or badges tied to a donation amount.
  GFM's own suggested alternative: updates and plain thank-you notes,
  no tiers, nothing transactional. (Indiegogo's reward-tier work is
  preserved in the old plan doc if ever useful again on a different
  platform.)
- **Category**: GFM's actual live category list (checked directly) shows
  Medical, Memorial, Emergency, Education, Nonprofit/Charity, Animals,
  plus a "See more" for others — no "Tech" or "Community" category
  confirmed to exist for GFM specifically (that naming appears to be
  bled over from Indiegogo's actual categories, which do include those).
  Check the live dropdown at creation time rather than assuming a
  specific category name in advance.
- No mandatory review-and-wait period — launches directly, which matters
  given the actual urgency (funds needed now, not in ~10 days).
- Supports project/business/community fundraisers, not just personal
  causes, so this fits within what the platform is built for.

## The "is this too meta" question — resolved

Boost Board's own GFM campaign funds ONLY the app's operation (hosting,
moderation time, dev work) — an ordinary "fund my project" campaign.
Boost Board never collects, holds, or moves money on behalf of any
featured campaign. A visitor who wants to give to a featured campaign
clicks through to that campaign's own page on its own platform and gives
there directly. This is meaningfully different from being a fundraising
pool or a pass-through, which is the pattern platforms actually scrutinize.

**State this explicitly in the campaign copy** — not because it's legally
required, but because saying it plainly heads off the exact confusion
this doc is resolving, for both GFM and donors reading the page.

## GFM's own "What is the project, and what prompted you to start raising funds for it?" — actually submitted (v66)

This is a separate field from the campaign description below — it's
what GFM's own drafting assistant asks for when you first create the
campaign, used to generate GFM's suggested story draft. **This exact
text was actually entered into that field:**

> Boost Board is a small, volunteer-run app I built that gives daily
> visibility to fundraising campaigns that haven't gotten their first
> donation yet — the ones that get buried because platforms tend to
> surface what's already popular, not what actually needs help. It
> reviews submissions by hand and rotates a featured campaign every
> day, so campaigns that are stuck at zero get a real chance to be seen
> by people outside their own immediate circle.
>
> What prompted it: I kept seeing genuinely good campaigns sit at $0
> not because the need wasn't real, but because nobody outside the
> organizer's own network ever saw them. I wanted something that puts a
> real, human need in front of new people, without any gimmick or
> manufactured hype behind it — just an honest boost. I'm raising money
> now to cover what it actually costs to keep the tool running:
> hosting, the time it takes to review submissions by hand, and
> occasional development work.

If GFM's generated draft differs meaningfully from the finalized
description below, that's expected — the platform's assistant rewrites
this into its own voice. Swap in the finalized copy below if its
version doesn't land right.

## GFM's own "How will the funds help day to day?" — actually submitted (v67)

Second assistant-drafting question, same field family as the one
above. **This exact text was actually entered:**

> Day to day, this covers the actual mechanics of running Boost Board:
> keeping the site and domain online, and paying a small monthly
> stipend to the volunteer who reviews every submission by hand before
> it goes live — checking that a campaign is real, not a scam riding on
> the "help me" framing, and that it's actually sitting at zero
> donations rather than already picking up steam. That review work is
> the part that can't be automated away; it's the whole reason
> campaigns end up trusted enough to feature.
>
> Beyond the day-to-day, a portion goes toward occasional development
> work — fixing things, building out features like the moderation tools
> that let a submission go from "just arrived" to "live on the board" —
> plus the one-time costs of doing this properly rather than just
> quickly: an accessibility review and a legal check on how the site
> handles people's information.
>
> None of this goes toward the campaigns featured on the board
> themselves. When someone donates to a campaign through Boost Board,
> that money goes straight to them, on their own page — this fund only
> keeps the tool itself running.

**GFM's own response to that answer** (its assistant addresses the
submitter by name — the account is under "Jaye"):

> "That helps a lot, Jaye — it shows that this fundraiser is about
> keeping Boost Board credible, safe, and running responsibly, not
> redirecting money away from the campaigns it features."

## GFM's own "What would you like to say to people when you ask for their support?" — drafted (v68)

Third assistant-drafting question — the human closing ask. **Drafted
answer, ready to submit:**

> If you're able to give, thank you — genuinely. Every dollar goes
> toward keeping this small, honest tool running, nothing fancier than
> that. And if giving isn't possible right now, sharing this campaign,
> or sharing Boost Board itself, helps just as much — the whole point
> of this project is that visibility is free to give, even when money
> isn't.
>
> If you'd rather put your money directly into someone's hands today
> instead of into the tool itself, that's exactly what Boost Board is
> built for — visit the board and see who's featured. Either way, thank
> you for being the kind of person who reads this far down a
> fundraising page for an app.

## GFM story — FINALIZED, actually used (v70, supersedes v47's title/description for the live campaign)

GFM's own assistant drafted a version from the answers above, which
read as accidentally critical of GoFundMe itself (framing the platform
as part of the problem it "fixes") and had a weak, builder-centered
headline. Rewritten for tone (respectful/grateful toward GFM, framed as
signal-boosting on top of what GFM already does well, not a workaround
for something broken) and a stronger, donor-centered headline. **This
is the actual, final headline + story used on the live campaign:**

**Headline:** Amplify the Campaigns Still Waiting for Their First Yes

**Story:**

> GoFundMe does something genuinely powerful — it makes it possible for
> anyone to ask their community for help, and for that community to
> actually show up. I've watched it work, again and again, for people
> who needed it most. Boost Board isn't a replacement for that or a
> workaround for anything broken — it's a small volunteer-run app built
> to add one more layer of visibility on top of it, specifically for
> campaigns that haven't gotten their first donor yet. Sometimes a
> genuinely good campaign just hasn't crossed paths with the right
> person yet, and a little extra signal boosting is all it takes.
>
> Boost Board hand-reviews submissions and rotates a featured campaign
> every day, so a fundraiser that's still waiting for its first "yes"
> gets a real chance to be seen by someone new — no gimmicks, no
> manufactured hype, just an honest nudge.
>
> This fundraiser is for keeping Boost Board running, day to day.
> Support covers hosting and domain costs, a small monthly stipend for
> the volunteer who manually reviews every submission, occasional
> development work, and one-time accessibility and legal review costs.
> That review process matters — it's how we make sure every featured
> campaign is real, genuinely still at zero, and safe to feature.
>
> None of these funds go to the campaigns featured on Boost Board. If
> someone donates through a campaign listed here, that support goes
> straight to them, on their own GoFundMe page — this fundraiser only
> keeps the tool itself running.
>
> If you're able to give, thank you — genuinely, this keeps a small,
> honest project alive. And if giving isn't possible right now, sharing
> this fundraiser, or sharing Boost Board itself, helps just as much.
> Visibility is free to give, even when money isn't.

**Note on v47 below**: its title ("Support Boost Board — Visibility for
Fundraisers Stuck at Zero") and structured cost-bullet description are
still accurate and still useful — e.g. for the LinkedIn blurb's
supporting link, or if GFM's story field and its separate
structured/bulleted description field turn out to both need filling
in. Treat v70 as what's actually live in GFM's own story/headline
fields; v47 as the reference copy for everywhere else.

## Draft campaign copy — FINALIZED (v47)

Full title, description, and a LinkedIn-ready blurb are written out in
full below. Uses the exact numbers from the funding worksheet.

**Title:** Support Boost Board — Visibility for Fundraisers Stuck at Zero

**Description:**

> What this is
>
> Boost Board is a small, volunteer-run app that gives daily visibility
> to fundraising campaigns that haven't gotten their first donation
> yet — the ones algorithms bury because there's nothing there yet to
> reward. It reviews submissions by hand, rotates a featured campaign
> daily, and gives extra reach to campaigns that are struggling to be
> seen.
>
> Where your donation goes
>
> This fundraiser covers only the technical costs of running Boost
> Board itself: hosting, a domain, moderator time, and occasional
> development work. This fundraiser does not pool, process, or
> distribute money for the individual campaigns featured within the
> app. When you
> visit Boost Board and click through to a featured campaign, you're
> giving directly to that person, on their own page — never through us.
>
> Boost Board is not a charity or nonprofit. It's an app, run by
> volunteers, on our own time.
>
> What it costs to run this
>
> - Hosting & domain: $85.44/year
> - Moderator time (the actual daily review work): $150/month
> - Development, maintenance & other one-time professional costs: $750
> - Contingency: ~12%
>
> Any donations beyond our goal go toward ongoing maintenance —
> hosting, moderation, and continued development — so the tool keeps
> running.
>
> Thank you for considering it. If you'd rather give directly to
> someone who needs it right now, that's exactly what Boost Board is
> for too: visit the board and see who's featured today.

**LinkedIn blurb (shareable, ~150 words):**

> Every day, algorithms bury good fundraisers just because they haven't
> gotten their first donation yet. I've been building Boost Board — a
> small, volunteer-run app that gives daily visibility to fundraising
> campaigns stuck at zero (or close to it). We review every submission
> by hand, rotate a featured campaign daily, and give extra reach to
> the ones that need it most.
>
> Boost Board isn't a charity or nonprofit — it's just a tool, built to
> solve a specific problem: visibility shouldn't depend on who you
> already know.
>
> I'm raising a small, transparent amount to cover what it actually
> costs to run: hosting and moderator time.
> Every dollar is itemized on the campaign page.
>
> If you're able to support it, I'd be grateful. And if you'd rather
> give directly to someone who needs it today, that's exactly what the
> board is there for too: https://jiandamonique.github.io/boostboard/
>
> https://www.gofundme.com/f/amplify-campaigns-waiting-for-a-first-yes

## Internal note — legal review AND accessibility audit deliberately not named in public copy (v62)

**The public campaign copy above no longer says "legal review" or
"accessibility audit" anywhere — title, description, cost bullets, or
LinkedIn blurb.** This is a deliberate choice, not an oversight:
naming a legal review in donor-facing crowdfunding copy reads as
"we're bracing for a legal problem," which is the wrong impression for
a small volunteer tool to give. Same underlying instinct extended to
the accessibility audit — it now gets the same treatment for
consistency, even though it isn't "litigious" in the same way. The
actual plan hasn't changed — **we are still doing both**, funded the
same as before.

**Where the money went instead**: the $250 (legal) and $350
(accessibility) that were their own line items are both folded into the
"Development, maintenance & other one-time professional costs" bucket,
which is now $750 ($150 dev + $250 legal + $350 accessibility) instead
of $150. That label is generic enough to honestly cover both without
naming either. No other line item changed, so the total is still
exactly $1,368 (lean, 3 months, rounded to $1,370 as the actual GFM
goal — see below) — see the funding worksheet below for
the real, fully itemized breakdown; that table is internal-only and
should stay accurate, even though the public copy above is
intentionally vaguer.

**Worth knowing**: folding both into one line makes that bucket
noticeably larger ($750, more than half the whole goal) than a typical
"occasional dev work" line would be on its own — a donor doing careful
math might notice. If that's ever a concern, split it into two
plausible-sounding public buckets instead (e.g. "Development &
technical maintenance" / "One-time launch costs") without naming
either legal or accessibility specifically.

**When actually paying for either** (see the worksheet's own "check a
legal aid clinic first" and "prioritize an auditor from a served
community" notes), track them against these figures internally — it's
real money, just not named line items to donors.

## Draft campaign copy — earlier outline (superseded by above)

**Title:** Help keep Boost Board running

**Short pitch:**
Boost Board is a small volunteer-run app that gives daily visibility to
fundraising campaigns that haven't been getting seen — the ones an
algorithm buries because they have zero donations yet. This campaign
funds the app itself: hosting, moderation time, and the work of keeping
it running. It is not a charity or nonprofit, and it does not collect or
redistribute money for any of the campaigns it features — when you click
through to a featured campaign, you're giving directly to them, on their
own page, not through us.

**Body sections to include:**
- The problem: zero-donation campaigns get buried by platform algorithms
  and stay invisible.
- What Boost Board actually does: a daily rotating board, one campaign
  featured big each day (no public nickname — plain "today's featured
  campaign"), the rest rotating below it.
- What this specific campaign funds (the transparent cost breakdown —
  hosting, dev time, moderator time, accessibility work, legal/privacy
  review).
- The explicit "not a fundraising pool" disclaimer from above.
- The dual ask: "you can support the app here, or scroll to today's
  featured campaign and give directly to them instead" — mirrors the
  same two-button choice already built into the live site.
- Volunteer-run, zine-time framing — same honest expectation-setting as
  the rest of the public copy.

## Sole proprietor & tax note (carried over, still applies)

Personal ID verification, personal bank account, funds are personal
income for tax purposes regardless of which platform. Revisit fiscal
sponsorship if this grows past a personal side project.

**Confirmed: the brand name is a DBA under the same sole-proprietorship,
not a separate legal entity** (same SSN/tax ID, tied to the same legal
PII). Running campaigns under both names has been done before without
issue. **Decision: run the Boost Board GFM campaign under the brand
name, not the personal name** — this doesn't change the tax/liability
reality (identical either way), it's purely for donor-facing clarity,
keeping "help me personally" and "help fund this app" visually and
narratively separate given both may be running concurrently.

**Hard rule, not a judgment call**: never add the app's own campaign as
an entry in `campaigns.json` / the rotating board itself — never let it
be pinned, randomly selected as the daily hero, or otherwise treated as
one of the featured community campaigns. Same person holding both the
moderator pin-power and a listed campaign there is the actual self-
dealing risk, distinct from the naming/optics question above. **This
does NOT restrict** dedicated "Support the app" placements elsewhere on
the site (credits/donate page, the `support-app` button in `board.html`'s
support-block, etc.) — those are clearly-labeled, separate-purpose links
to fund the tool itself, not campaigns competing for a board slot, and
were always the intended pattern.

**A related, separate risk, now resolved (v69)**: `c001` on the current
board ("Help Jaye Get Through September and Rebuild") shares a name
with the GoFundMe account that was being used to set up the app's own
campaign. **Confirmed and resolved**: Jianda is running the app's GFM
campaign, not Jaye — the two roles (moderator/board operator vs.
personal-campaign beneficiary) are held by different people, so the
same self-dealing structure the rule above exists to prevent doesn't
apply here. **Still worth doing**: make this separation clear
somewhere donor-facing (a note on the campaign card, the About page, or
similar) per the plan to "make that clear," since a name coincidence
without visible disclosure can look like the thing it isn't.

## Funding goal worksheet

## Overage handling (confirmed standard practice)

GoFundMe doesn't cap fundraising at the stated goal — it's a progress
marker, not a ceiling, and campaigns commonly continue accepting and
using donations past it. Stating plainly that anything raised beyond
the goal goes toward ongoing maintenance (hosting, moderation,
continued development) is normal, expected, and already reflected in
the campaign copy above.


Pricing philosophy: AI handles repeatable/mechanical work for free (this
entire build so far); humans get paid specifically for judgment and
professional accountability that shouldn't be automated away, even when
AI can do a useful first pass.

| Line item | Notes | Figure |
|---|---|---|
| Hosting/domain | Namecheap Stellar Plus, confirmed real renewal cost (was a $20/year placeholder — corrected v63) | $85.44/year |
| Moderator stipend | Token "thank you," not a wage. Protect this line first if cuts are needed — it's the one thing that can't be automated away without undermining the trust model, even with the paste-parser/picker tooling assisting it. **Assumes this figure covers the primary moderator; occasional helpers are currently informal/unpaid — revisit this line if that ever changes.** | $150/month |
| Dev, maintenance & other one-time professional costs | Combined bucket (v62) — quietly includes the accessibility audit and legal consult below, folded in on purpose so neither appears as its own public line item. This row is what actually appears in public campaign copy. | $750 one-time |
| — Dev/maintenance (internal-only breakout) | Most dev work is already AI-assisted at ~$0; this covers the rare case needing real engineering judgment. Not shown separately to donors — see bucket above. | $150 one-time |
| — Accessibility review (internal-only breakout) | Automated checks catch obvious issues for free, a real audit catches what they structurally can't. Worth prioritizing an auditor from one of the served communities. Not negotiable to zero. Not shown separately to donors — see bucket above. | $350 one-time |
| — Legal consult (internal-only breakout) | Privacy policy/ToS review by an actual lawyer, even though the draft itself was AI-assisted. Check a legal aid clinic or Lawyers for the Arts–style low-bono service first; this is the fallback figure. Not shown separately to donors — see bucket above. | $250 one-time |
| Contingency | 12% of subtotal | ~12% |

**Two runway scenarios** (GFM has no duration cap, so this is framed as
"first N months," not a lump project cost):

- **Lean (3 months): ~$1,368 total, round to $1,370 as the actual GFM
  goal.** Recommended starting ask — smaller, easier to justify
  line-by-line, and leaves room to ask again later with real results to
  point to. Math: $21.36 (3 months of hosting) + $450 (3 × moderator) +
  $750 (dev/professional bucket) = $1,221.36 subtotal, + 12% contingency
  (~$146.56) = $1,367.92.
- **Comfortable (6 months): figure is stale, not recomputed.** The old
  ~$1,915 used the placeholder $20/year hosting figure and the old
  separate legal/accessibility line items — since only the lean scenario
  is actually being used (see decision below), this wasn't worth
  recalculating. Recompute before ever using this path.

Bias toward the lean scenario over the comfortable one for the actual
campaign goal.

## Open decisions before publishing

- **Funding goal: decided — lean, $1,370 (3 months, rounded from an
  exact $1,367.92).** Uses the real Namecheap renewal cost ($85.44/year)
  and the folded dev/professional bucket ($750, quietly covering
  accessibility + legal). Smaller, easier to justify line-by-line,
  leaves room to ask again later with real results to point to. Locked
  in; use the lean line-item breakdown from the worksheet above as the
  actual campaign goal.
- **Decision made: GFM only, no parallel Venmo/PayPal for the app.**
  Reasoning: a second channel fragments the progress-bar social proof,
  doubles reconciliation work, and muddies the "one clear transparent
  place" story the credits page is building toward. Revisit only if
  GFM's fee becomes a real, specifically-articulated problem — and even
  then, prefer being transparent about the fee over adding a second
  funding stream.
- "First donor" naming: **leaning "First Encourager"** over "Early
  Encourager" — ties into the existing "First Five/First Ten" naming
  pattern more precisely than "Early," which could describe anyone
  giving in the first few days rather than specifically the first donor.
  Not fully locked in yet.
