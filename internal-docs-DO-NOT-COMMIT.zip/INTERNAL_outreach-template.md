# INTERNAL — Outreach Template
(Never commit this file or this folder to GitHub.)

Excerpted from `INTERNAL_moderator-handbook.md` for quick reference —
the handbook stays the source of truth if these ever drift out of sync.

## Notifying featured campaign owners (good faith, no reply expected)

When a campaign is actually featured (hits the board or becomes the
hero), send a short courtesy note. This is good faith outreach, not a
request for anything — make that explicit in the message itself, and
don't treat a non-reply as anything other than normal.

**Why the wording matters, specifically**: a common scam pattern looks
exactly like a "good news" outreach message — "you've been selected for
a free donation, email us to claim it" — that then leads to an upsell
once the person responds. Boost Board's message needs to read as the
opposite of that on first glance: no claiming, no action required to
"unlock" anything, nothing that only makes sense if the person replies.
State plainly that it already happened or is about to happen regardless
of any response.

Two short variants, depending on timing:

**If the campaign is already live on the board:**

> Subject: Your campaign is featured on Boost Board
>
> Hi [name],
>
> Just an FYI — your campaign is currently featured on Boost Board:
> [link]. This already happened; there's nothing you need to do. If
> you'd like us to add or change anything about how it's shown, let us
> know — otherwise no reply needed at all.
>
> Boost Board is a small volunteer-run project that gives daily
> visibility to fundraising campaigns that haven't gotten much reach
> yet.
>
> Take care,
> The Boost Board team

**If a moderator found the campaign and is about to add it (sourced,
not self-submitted):**

> Subject: We're featuring your campaign on Boost Board
>
> Hi [name],
>
> We came across your campaign and we're planning to feature it on
> Boost Board, a small volunteer-run project that gives visibility to
> fundraisers that haven't gotten much reach yet: [link to Boost Board].
> This isn't something you need to respond to or do anything about — if
> you'd rather we didn't, or want us to add/change something first, just
> let us know.
>
> Take care,
> The Boost Board team

Keep the merge fields (`[name]`, `[link]`) consistent so this is easy to
template into an automated send later — the message is written to be
equally sendable by a human copy-pasting it today or a script firing it
automatically once the project can support that, without changing the
wording. Automation-friendly today just means: don't write anything into
this template that only makes sense coming from a human typing it live.

**Consequence for data retention**: this means submitter email can no
longer be deleted immediately after initial review, since the campaign
may not actually be featured until days or weeks later. See the updated
retention window in `INTERNAL_data-retention.md`.
